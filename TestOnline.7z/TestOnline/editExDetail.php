
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>แก้ไขคำถาม</title>
</head>
<body>

  <?php
  $date = date("Y-m-d");
  function getNumDay($d1,$d2){
    $dArr1    = preg_split("/-/", $d1);
    list($year1, $month1, $day1) = $dArr1;
    $Day1 =  mktime(0,0,0,$month1,$day1,$year1);

    $dArr2    = preg_split("/-/", $d2);
    list($year2, $month2, $day2) = $dArr2;
    $Day2 =  mktime(0,0,0,$month2,$day2,$year2);

    return round(abs( $Day2 - $Day1 ) / 86400 )+1;
  }

  ?>
  <div id="wrapper">
    <?php
 if(isset($_GET['Edit_ex_D_Id'])){
    $ex_d_id = $_REQUEST["Edit_ex_D_Id"];
  }
    $ex_d_header_id ="";
    $ex_d_title ="";
    $ex_s_id ="";
    $ex_s_A ="";
    $ex_s_B ="";
    $ex_s_C ="";
    $ex_s_D ="";
    $ex_s_cheap ="";
    require_once("mysqlconnect.php");
    include('manu.php');
    $sql="SELECT ed.ex_d_id,ed.ex_d_header_id,ed.ex_d_title, es.ex_s_id,es.ex_s_A,es.ex_s_B,es.ex_s_C,es.ex_s_D,es.ex_s_cheap FROM examination_detail ed,examination_subitem es WHERE ed.ex_d_id = es.ex_s_d_id AND ed.ex_d_id ='$ex_d_id'";
    $result = $dbc->query($sql);
    if ($result->num_rows > 0) {
      while($row = $result->fetch_assoc()){
        $ex_d_header_id = $row["ex_d_header_id"];
        $ex_d_title = $row["ex_d_title"];
        $ex_s_id = $row["ex_s_id"];
        $ex_s_A= $row["ex_s_A"];
        $ex_s_B =$row["ex_s_B"];
        $ex_s_C =$row["ex_s_C"];
        $ex_s_D =$row["ex_s_D"];
        $ex_s_cheap =$row["ex_s_cheap"];
      }
    }

    ?>
    <div id="page-wrapper">
     <div class="container-fluid">
      <div class="row">
        <div class="col-lg-12">
          <h1 class="page-header">
            แก้ไขคำถาม
          </h1>
        </div>
      </div>
      <div class="row">
        <div class="col-lg-12">
          <form class="form-horizontal" action="" id="myform1" name="frmMain" method="post" onkeypress="return event.keyCode != 13;" >

            <div class="row">
              <div class="col-sm-12 ">
                <label for="inputEmail3" class="col-sm-2 control-label">คำถาม<t style="color: #ff0000;">*</t></label>
                <div class="col-sm-8 form-group ">
                  <textarea row="6" class="form-control css-require" id="exampleInputEmail2" placeholder="คำถาม" name="txtex_detail"> <?php echo($ex_d_title);?></textarea>
                  <input type="text" hidden name="txtex_d_id" value="<?php echo($ex_d_id);?>" >
                  <input type="text" name="txtex_s_id" value="<?php echo($ex_s_id);?>" hidden>
                  <input type="text" name="txtex_d_header_id" value="<?php echo($ex_d_header_id);?>" hidden>
                </div>
              </div>
            </div>

            <div class="row">
              <div class="col-sm-12 ">
                <label for="inputEmail3" class="col-sm-3 control-label">A<t style="color: #ff0000;">*</t></label>
                <div class="col-sm-7 form-group ">
                  <input type="text"class="form-control css-require" id="exampleInputEmail2" placeholder="คำตอบ A" name="txtex_s_A" value="<?php echo($ex_s_A);?>">
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-sm-12 ">
                <label for="inputEmail3" class="col-sm-3 control-label">B<t style="color: #ff0000;">*</t></label>
                <div class="col-sm-7 form-group ">
                  <input type="text" class="form-control css-require" id="exampleInputEmail2" placeholder="คำตอบ B" name="txtex_s_B" value="<?php echo($ex_s_B);?>">
                </div>
              </div>
            </div>

            <div class="row">
              <div class="col-sm-12 ">
                <label for="inputEmail3" class="col-sm-3 control-label">C<t style="color: #ff0000;">*</t></label>
                <div class="col-sm-7 form-group ">
                  <input type="text" class="form-control css-require" id="exampleInputEmail2" placeholder="คำตอบ C" name="txtex_s_C" value="<?php echo($ex_s_C);?>">
                </div>
              </div>
            </div>

            <div class="row">
              <div class="col-sm-12 ">
                <label for="inputEmail3" class="col-sm-3 control-label">D<t style="color: #ff0000;">*</t></label>
                <div class="col-sm-7 form-group ">
                  <input type="text" class="form-control css-require" id="exampleInputEmail2" placeholder="คำตอบ D" name="txtex_s_D" value="<?php echo($ex_s_D);?>">
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-sm-12 ">
                <label for="inputEmail3" class="col-sm-4 control-label">จงเลือกคำตอบที่ถูกต้อง<t style="color: #ff0000;">*</t></label>
                <div class="radio col-sm-1">
                  <label >
                    <?php 
                    if($ex_s_cheap =="A"){
                      ?>
                      <input type="radio" name="radcheap" value="A" checked> A
                      <?php
                    }else{
                      ?>
                      <input type="radio" name="radcheap" value="A" > A
                      <?php
                    }
                    ?>
                  </label>
                </div>
                <div class="radio col-sm-1">
                  <label >
                    <?php 
                    if($ex_s_cheap =="B"){
                      ?>
                      <input type="radio" name="radcheap" value="B" checked> B
                      <?php
                    }else{
                      ?>
                      <input type="radio" name="radcheap" value="B" > B
                      <?php
                    }
                    ?>
                  </label>
                </div>
                <div class="radio col-sm-1">
                  <label >
                    <?php 
                    if($ex_s_cheap =="C"){
                      ?>
                      <input type="radio" name="radcheap" value="C" checked> C
                      <?php
                    }else{
                      ?>
                      <input type="radio" name="radcheap" value="C" > C
                      <?php
                    }
                    ?>
                  </label>
                </div>
                <div class="radio col-sm-1">
                  <label >
                    <?php 
                    if($ex_s_cheap =="D"){
                      ?>
                      <input type="radio" name="radcheap" value="D" checked> D
                      <?php
                    }else{
                      ?>
                      <input type="radio" name="radcheap" value="D" > D
                      <?php
                    }
                    ?>
                  </label>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-sm-12 ">
                <label for="inputEmail3" class="col-sm-8 control-label"></label>
                <button type="button" onclick="window.history.back()" class="btn btn-default" >ยกเลิก</button>
                <button type="submit" class="btn btn-primary" name="subEditsubitem">บันทึก</button>
              </div>
            </div>
            <br>
          </form>
        </div>
      </div>
    </div>
  </div>
  <?php
  if(isset($_POST['subEditsubitem'])){
    $ex_d_id= $_POST['txtex_d_id'];
    $ex_s_id= $_POST['txtex_s_id'];
    $ex_header_id =$_POST['txtex_d_header_id'];
    $ex_d_title = $_POST['txtex_detail'];
    $ex_s_A =$_POST['txtex_s_A'];
    $ex_s_B=$_POST['txtex_s_B'];
    $ex_s_C=$_POST['txtex_s_C'];
    $ex_s_D=$_POST['txtex_s_D'];
    $ex_s_cheap=$_POST['radcheap'];

    $stmt_d = $dbc->prepare("UPDATE examination_detail SET ex_d_title =? WHERE  ex_d_id ='$ex_d_id'" );
    $stmt_d->bind_param("s",$ex_d_title);
    $stmt_d->execute();

    $stmt_S = $dbc->prepare("UPDATE examination_subitem SET ex_s_A = ? ,ex_s_B = ? ,ex_s_C = ? ,ex_s_D = ? ,ex_s_cheap = ? WHERE ex_s_id = '$ex_s_id' ");
    $stmt_S->bind_param("sssss",$ex_s_A,$ex_s_B,$ex_s_C,$ex_s_D,$ex_s_cheap);
    $stmt_S->execute();

    ?>
    <div class="container">
      <div class="modal show" id="myModal" role="dialog">
        <div class="modal-dialog">

          <!-- Modal content-->
          <div class="modal-content">
            <div class="modal-header">
              <a href="examinationDetail.php?exId=<?=$ex_header_id;?>" type="button" class="close"   data-dismiss="modal">&times;</a>
              <h4 class="modal-title">สำเร็จ</h4>
            </div>
            <div class="modal-body">
              <p>แก้ไขข้อมูลของสำเร็จ .</p>
            </div>
            <div class="modal-footer">
              <a type="button" href="examinationDetail.php?exId=<?=$ex_header_id;?>"  class="btn btn-default"  data-dismiss="modal">Close</a>
            </div>
          </div>

        </div>
      </div>
    </div>
    <?php
  }
  if(isset($_GET["dleteEx_id"])){
    $ex_d_id = $_REQUEST["dleteEx_id"];
    $exs_id= $_REQUEST["dleteEx_s_id"];
    $ex_header_id= $_REQUEST["ex_header_id"];
    
    $delete1 = $dbc->prepare("DELETE FROM examination_detail WHERE ex_d_id = ?");
    $delete1->bind_param("s",$ex_d_id);
    $delete1->execute();

     $delete2 = $dbc->prepare("DELETE FROM examination_subitem WHERE ex_s_id = ?");
    $delete2->bind_param("s",$exs_id);
    $delete2->execute();

    ?>
    <div class="container">
      <div class="modal show" id="myModal" role="dialog">
        <div class="modal-dialog">

          <!-- Modal content-->
          <div class="modal-content">
            <div class="modal-header">
              <a href="examinationDetail.php?exId=<?=$ex_header_id;?>" type="button" class="close"   data-dismiss="modal">&times;</a>
              <h4 class="modal-title">สำเร็จ</h4>
            </div>
            <div class="modal-body">
              <p>ลบข้อมูลของสำเร็จ </p>
            </div>
            <div class="modal-footer">
              <a type="button" href="examinationDetail.php?exId=<?=$ex_header_id;?>"  class="btn btn-default"  data-dismiss="modal">Close</a>
            </div>
          </div>

        </div>
      </div>
    </div>
    <?php
  }
  ?>
  <script src="js/jquery.js"></script>
  <script src="js/checkforms.js"></script>
  <script src="js/inputdate.js"></script>
  <script src="js/jquery.datetimepicker.js"></script>
  <script src="build/jquery.datetimepicker.full.js"></script>
</body>
</html>