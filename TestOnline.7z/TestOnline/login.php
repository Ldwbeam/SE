	<?php 
	error_reporting( error_reporting() & ~E_NOTICE );
	session_start();
	if($_SESSION['u_id']!=""){
		header("location:index.php");
	}
	?>
	<!DOCTYPE html>
	<html lang="en">

	<head>

		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="shortcut icon" href="img/shop.jpg" type="image/x-icon">
		<meta name="description" content="">
		<meta name="author" content="">
		<title>LoginForm</title>
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<link href="css/blog-post.css" rel="stylesheet">
	</head>
	<body>

		<div class="container-fluid">
			<div class="row" align="Center" style="margin-top: 130px;">

				<div class="col-md-4"></div>
				<div class="col-md-4" align="Center" >
					<img src="img/rebirth.png" alt="..."/>
					<form class="form-horizontal" action=""  method="post">
						<div class="form-group">
							<label for="inputEmail3" class="col-sm-2 control-label">UserName</label>
							<div class="col-sm-10">
								<input  class="form-control" name="txtUserName" placeholder="UserName">
							</div>
						</div>
						<div class="form-group">
							<label for="inputPassword3" class="col-sm-2 control-label">Password</label>
							<div class="col-sm-10">
								<input type="password" name="txtPassWord" class="form-control" id="inputPassword3" placeholder="Password">
							</div>
						</div>
						<div class="form-group">
							<div class="col-sm-offset-2 col-sm-10">
								<a href="register.php" class="btn btn-default">สมัครสมาชิก</a> 
								<button type="submit" style="margin: 10px;" name="bntLogin" class="btn btn-default">เข้าสู่ระบบ</button>
							</div>
						</div>
					</form>
				</div>
				<div class="col-md-4"></div>
			</div>
		</div>
	</div>
	<?php  
	session_start();
	require_once("mysqlconnect.php");
	if(isset($_POST['bntLogin'])){
		$username=$_POST['txtUserName'];
		$password=$_POST['txtPassWord'];
		$_SESSION['u_id']= "";
		$_SESSION['u_class']= "";
		$_SESSION['u_schoolID']= "";
		$_SESSION['nameAdmin']= "";
		$_SESSION['userType']= "";
		$sql=" SELECT * FROM users WHERE u_userName = '$username' AND   u_password = '$password' ";
		$result = $dbc->query($sql);
		if ($result->num_rows > 0) {
			while($row = $result->fetch_assoc()){

				$_SESSION['u_id'] =$row["u_id"];
				$_SESSION['nameAdmin']= $row["u_firstName"] ." ". $row["u_lastName"];
				$_SESSION['userType'] = $row['u_type'];
				$_SESSION['u_class']= $row['u_class'];
				$_SESSION['u_schoolID']= $row['u_schoolID'];
				if($row['u_type'] =="2"){
					header("location:admin/index.php");
				}else{
					header("location:index.php");
				}	
			}
		}else{ ?>
			<div class="container">
				<div class="modal show" id="myModal" role="dialog">
					<div class="modal-dialog">

						<!-- Modal content-->
						<div class="modal-content">
							<div class="modal-header">
								<a href="login.php" type="button" class="close"  onclick = "$('.modal').removeClass('show').addClass('fade');" data-dismiss="modal">&times;</a>
								<h4 class="modal-title">เกิดข้อผิดผลาด</h4>
							</div>
							<div class="modal-body">
								<p>User Name หรือ Password ไม่ถูกต้องโปรดลองอีกครั้ง!!!.</p>
							</div>
							<div class="modal-footer">
								<a type="button" href="login.php"  class="btn btn-default" onclick = "$('.modal').removeClass('show').addClass('fade');" data-dismiss="modal">Close</a>
							</div>
						</div>

					</div>
				</div>
			</div>
			<?php
		}

	}
	?>

	<!-- jQuery -->
	<script src="js/jquery.js"></script>
	<!-- Bootstrap Core JavaScript -->
	<script src="js/bootstrap.min.js"></script>

</body>

</html>
