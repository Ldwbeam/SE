
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>รายละเอียดคะแนน</title>
  <style type="text/css">
    .imghead{}

    img{
      width: 250px;
      height: 250px;
      margin-top: 2px;
      text-align: center;
      -moz-box-shadow: 5px 5px 5px #fff;  
      -webkit-box-shadow: 5px 5px 5px #fff;  
      box-shadow: 5px 5px 5px #fff;

    }
    .b{
      color: #BDBDBD;
      margin-left: 0%;
      font-size: 12px;
    }

    .comment{
      margin-left: 20px;
    }
    .comment h4{
      margin-left: 10px;
      font-size: 11px;
      color: #424242;

    }
    .imga{
      text-align: center;
      width: 180px;
      height: 100px;
      margin-left: 5%;
    }
    .scrollbar10{
      width:100%;
      height:400px;
      overflow-y:scroll;


    }
    #ex10::-webkit-scrollbar{
      width:10px;


    } 
    #ex10::-webkit-scrollbar-thumb{

      border-radius:10px;
    }
    #ex10::-webkit-scrollbar-thumb:hover{
      background-color:#90CAF9;
      border:10px solid #90CAF9;

    }
    #ex10::-webkit-scrollbar-thumb:active{
      background-color:#BBDEFB;
      border:10px solid #BBDEFB;

    } 
    #ex10::-webkit-scrollbar-track{
      border:2px ;
      border-radius:10px;

    </style>

  </head>
  <body>
   <div id="wrapper">

    <?php
    $date = date("Y-m-d");
    function DateThai($strDate)
    {
      $strYear = date("Y",strtotime($strDate))+543;
      $strMonth= date("n",strtotime($strDate));
      $strDay= date("j",strtotime($strDate));
      $strHour= date("H",strtotime($strDate));
      $strMinute= date("i",strtotime($strDate));
      $strSeconds= date("s",strtotime($strDate));
      $strMonthCut = Array("","ม.ค.","ก.พ.","มี.ค.","เม.ย.","พ.ค.","มิ.ย.","ก.ค.","ส.ค.","ก.ย.","ต.ค.","พ.ย.","ธ.ค.");
      $strMonthThai=$strMonthCut[$strMonth];
      return "$strDay $strMonthThai $strYear";
    }
    require_once("mysqlconnect.php");
    include('manu.php');

    $IDUsers =$_SESSION['u_id'];
    $exId = $_REQUEST["exId"];

    $ex_d_header_id ="";
    $ex_detail ="";
    $ex_name ="";
    $ex_course ="";
    $ex_numberExams ="";
    $ex_class ="";
    $ex_OpenExam ="";
    $ex_CloseExam ="";

    $sql=" SELECT EH.ex_id,EH.ex_id,EH.ex_name,EH.ex_detail,EH.ex_course,EH.ex_numberExams,EH.ex_idProfessor,EH.ex_date,EH.ex_class,EH.ex_OpenExam,EH.ex_CloseExam,U.u_firstName,U.u_lastName ,S.NameSchool FROM examination_header EH, users U,school S WHERE EH.ex_idProfessor =U.u_id AND U.u_schoolID=s.IDSchool AND ex_id = '$exId'";
    $result = $dbc->query($sql);
    if ($result->num_rows > 0) {
      while($row = $result->fetch_assoc()){
        $ex_d_header_id = $row["ex_id"];
        $ex_name = $row["ex_name"];
        $ex_detail =$row["ex_detail"];
        $ex_course= $row["ex_course"];
        $ex_numberExams =$row["ex_numberExams"];
        $ex_class =$row["ex_class"];
        $ex_OpenExam =$row["ex_OpenExam"];
        $ex_CloseExam =$row["ex_CloseExam"];
      }
    }

    ?>
    <div id="page-wrapper">
     <div class="container-fluid">
      <div class="row">
        <div class="col-lg-12">
          <h1 class="page-header">
           คะแนนสอบของนักเรียน
         </h1>
         <ol class="breadcrumb">
          <li class="active">
            <i class="glyphicon glyphicon-th"></i>  <?php echo( "<b>รายละเอียด รหัสชุดข้อสอบ </b>". $ex_d_header_id." เรื่อง" .$ex_name." จำนวน ". $ex_numberExams." ข้อ"." รายวิชา".$ex_course ." อาจารย์ประจำวิชา ". $ex_NameProfessor . " ". $NameSchool ) ?>
            
          </li>
        </ol>
      </div>
    </div>

    <BR>
    <div class="col-lg-12 scrollbar table-responsive" id="ex3">
      <table class="table table table-bordered table-hover " >
        <thead>
          <tr>
            <th>#</th>
            <th>ชื่อ/นามสกุล</th>
            <th>รหัสประจำตัว</th>
            <th>ชั้นเรียน</th>
            <th>ได้คะแนน</th>
            <th>ผลการสอบ</th>
          </tr>
        </thead>
        <tbody class="">
          <?php
          $sql="SELECT es.IDExamScore,es.ExamScore,es.IDExamination,es.IDUsers,es.ExamDate,u.u_firstName,u.u_lastName,u.u_studentCode,u.u_class FROM examscore es , users u WHERE es.IDUsers = u.u_id AND es.IDExamination = '$exId'";
          $result = $dbc->query($sql);
          $l=1;
          if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
             $numberExams =($ex_numberExams / 2);
             if($row["ExamScore"] < $numberExams){
               ?>
               <tr class="danger">
                <td ><?php echo($l++); ?></td>
                <td ><?php echo($row["u_firstName"]." ".$row["u_lastName"]); ?></td>
                <td ><?php echo($row["u_studentCode"]); ?></td>
                <td ><?php echo($row["u_class"]); ?></td>
                <td ><?php echo($row["ExamScore"]); ?></td>
                <td ><font color="#FF0000"> สอบไม่ผ่าน</font></td>
              </tr>
              <?php  
            }else{
             ?>
             <tr class="active">
              <td ><?php echo($l++); ?></td>
              <td><?php echo($row["u_firstName"]." ".$row["u_lastName"]); ?></td>
              <td ><?php echo($row["u_studentCode"]); ?></td>
              <td ><?php echo($row["u_class"]); ?></td>
              <td ><?php echo($row["ExamScore"]); ?></td>
              <td >สอบผ่าน</td>
            </tr>
            <?php  
          }
        }
      }
      ?>
    </tbody>
  </table>
</div>

</div>
</div>
</div>
</body>
</html>