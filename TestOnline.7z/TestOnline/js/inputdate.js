function ck_frm(){
		var ck = document.getElementById('ckk');
		if(ck.checked == true){
	    	document.getElementById('frm_txt4').style.display = "none";
		    //document.getElementById('frm_txt4').
		    document.getElementById('frm_txt3').style.display = "none";
	        document.getElementById('frm_txt1').style.display = "none";
	        document.getElementById('frm_txt5').style.display = "none";
			document.getElementById('frm_txt').style.display = "";
			//document.getElementById("chkDel").checked=false;
			$(".faculty").attr("checked",false);
			$(".program").attr("checked",false);
			$(".studensum").attr("checked",false);
			//$("#studentnumber").val("");
			//$(".studentnumber").val("");
			//studentnumber.value="";
			//alert("yyyy");
		}else{

		document.getElementById('frm_txt').style.display = "none";
		}
		}
		function ck1_frm(){
		var ck = document.getElementById('ckk1');
		if(ck.checked == true){

        document.getElementById('frm_txt4').style.display = "none";
        document.getElementById('frm_txt3').style.display = "none";
        document.getElementById('frm_txt').style.display = "none";
        document.getElementById('frm_txt5').style.display = "none";
		document.getElementById('frm_txt1').style.display = "";
		$(".generation").attr("checked",false);
		$(".program").attr("checked",false);
		$(".studensum").attr("checked",false);

		}else{
      
		document.getElementById('frm_txt1').style.display = "none";
		}
		}

		function ck3_frm(){
		var ck = document.getElementById('ckk3');
		if(ck.checked == true){
		document.getElementById("chkDel").checked=false;
		document.getElementById('frm_txt4').style.display = "none";
		document.getElementById('frm_txt').style.display = "none";
        document.getElementById('frm_txt1').style.display = "none";
		document.getElementById('frm_txt3').style.display = "";
		document.getElementById('frm_txt5').style.display = "none";
		$(".generation").attr("checked",false);
		$(".faculty").attr("checked",false);
		$(".studensum").attr("checked",false);

		}else{
		
		document.getElementById('frm_txt3').style.display = "none";
		}
		}

		function ck4_frm(){
		var ck = document.getElementById('ckk4');
		if(ck.checked == true){
		document.getElementById('frm_txt').style.display = "none";
        document.getElementById('frm_txt1').style.display = "none";
		document.getElementById('frm_txt3').style.display = "none";
		document.getElementById('frm_txt4').style.display = "";
		document.getElementById('frm_txt5').style.display = "none";
		$(".generation").attr("checked",false);
		$(".faculty").attr("checked",false);
		$(".program").attr("checked",false);

		}else{
		
		document.getElementById('frm_txt4').style.display = "none";
		}
		}

		function ck5_frm(){
		var ck = document.getElementById('ckk5');
		if(ck.checked == true){
		document.getElementById('frm_txt').style.display = "none";
        document.getElementById('frm_txt1').style.display = "none";
		document.getElementById('frm_txt3').style.display = "none";
		document.getElementById('frm_txt4').style.display = "none";
		document.getElementById('frm_txt5').style.display = "";
		$(".generation").attr("checked",false);
		$(".faculty").attr("checked",false);

		}else{
		
		document.getElementById('frm_txt5').style.display = "none";
		}
		}

  
		
/*
function chk1(vol)
	{
	
		var i=1;
		for(i=1;i<=document.frmMain.hdnCount.value;i++)
		{
			if(vol.checked == true)
			{
				eval("document.frmMain.chkDel"+i+".checked=true");
			}
			else
			{
				eval("document.frmMain.chkDel"+i+".checked=false");
			}
		}
	}
/*
	function onDelete()
	{
		if(confirm('Do you want to delete ?')==true)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
*/
$(function(){
    

    var optsDate = {  
        format:'Y-m-d', // รูปแบบวันที่ 
        formatDate:'Y-m-d',
        timepicker:false,   
        closeOnDateSelect:true,
    } 
    var optsTime = {
        format:'H:i', // รูปแบบเวลา
        step:30,  // step เวลาของนาที แสดงค่าทุก 30 นาที 
        formatTime:'H:i',
        datepicker:false,
    }    
    var setDateFunc = function(ct,obj){
        var minDateSet = $("#startDate").val();
        var maxDateSet = $("#endDate").val();
        
        if($(obj).attr("id")=="startDate"){
            this.setOptions({
                minDate:false,
                maxDate:maxDateSet?maxDateSet:false
            })                   
        }
        if($(obj).attr("id")=="endDate"){
            this.setOptions({
                maxDate:false,
                minDate:minDateSet?minDateSet:false
            })                   
        }
    }
    
    var setTimeFunc = function(ct,obj){
        var minDateSet = $("#startDate").val();
        var maxDateSet = $("#endDate").val();        
        var minTimeSet = $("#startTime").val();
        var maxTimeSet = $("#endTime").val();
        
        if(minDateSet!=maxDateSet){
            minTimeSet = false;
            maxTime = false;
        }
        
        if($(obj).attr("id")=="startTime"){
            this.setOptions({
                maxDate:maxDateSet?maxDateSet:false,
                minTime:false,
                maxTime:maxTimeSet?maxTimeSet:false        
            })                   
        }
        if($(obj).attr("id")=="endTime"){
            this.setOptions({
                minDate:minDateSet?minDateSet:false,
                maxTime:false,
                minTime:minTimeSet?minTimeSet:false      
            })                   
        }
    }    
    
    $("#startDate,#endDate").datetimepicker($.extend(optsDate,{  
        onShow:setDateFunc,
        onSelectDate:setDateFunc,
    }));
    
    $("#startTime,#endTime").datetimepicker($.extend(optsTime,{  
        onShow:setTimeFunc,
        onSelectTime:setTimeFunc,
    }));    
    
    
    
});
 
