
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>สร้างคำถาม</title>
</head>
<body>

  <?php
  $date = date("Y-m-d");
  function getNumDay($d1,$d2){
    $dArr1    = preg_split("/-/", $d1);
    list($year1, $month1, $day1) = $dArr1;
    $Day1 =  mktime(0,0,0,$month1,$day1,$year1);

    $dArr2    = preg_split("/-/", $d2);
    list($year2, $month2, $day2) = $dArr2;
    $Day2 =  mktime(0,0,0,$month2,$day2,$year2);

    return round(abs( $Day2 - $Day1 ) / 86400 )+1;
  }

  ?>
  <div id="wrapper">
    <?php
    $ex_id = $_REQUEST["exId"];
    $ex_d_header_id ="";
    $ex_name ="";
    $ex_NameProfessor ="";
    $ex_course ="";
    $NameSchool ="";
    $ex_numberExams ="";
    require_once("mysqlconnect.php");
    include('manu.php');
    $sql=" SELECT EH.ex_id,EH.ex_id,EH.ex_name,EH.ex_detail,EH.ex_course,EH.ex_numberExams,EH.ex_idProfessor,EH.ex_date,U.u_firstName,U.u_lastName ,S.NameSchool FROM examination_header EH, users U,school S WHERE EH.ex_idProfessor =U.u_id AND U.u_schoolID=s.IDSchool AND ex_id = '$ex_id'";
    $result = $dbc->query($sql);
    if ($result->num_rows > 0) {
      while($row = $result->fetch_assoc()){
        $ex_d_header_id = $row["ex_id"];
        $ex_name = $row["ex_name"];
        $ex_course= $row["ex_course"];
        $ex_NameProfessor = $row["u_firstName"] . " ".$row["u_lastName"];
        $NameSchool= $row["NameSchool"];
        $ex_numberExams =$row["ex_numberExams"];
      }
    }

    ?>
    <div id="page-wrapper">
     <div class="container-fluid">
      <div class="row">
        <div class="col-lg-12">
          <h1 class="page-header">
            สร้างคำถาม
          </h1>
          <ol class="breadcrumb">
            <li class="active">
              <i class="glyphicon glyphicon-th"></i>  <?php echo( "<b>รายละเอียด รหัสชุดข้อสอบ </b>". $ex_d_header_id." เรื่อง" .$ex_name." จำนวน ". $ex_numberExams." ข้อ"." รายวิชา".$ex_course ." อาจารย์ประจำวิชา ". $ex_NameProfessor . " ". $NameSchool ) ?>
              <a href="createAnExam.php?editEx_id=<?= $ex_d_header_id;?>"> <b>แก้ไข</b></a>
              <a href="createAnExam.php?DeletEx_id=<?= $ex_d_header_id;?>"> <b>ลบ</b></a>
            </li>
          </ol>
        </div>
      </div>

      <div class="row">
        <div class="col-lg-12">
          <?php 
          $numberitem ="";
          $sqlit="SELECT COUNT(ex_d_title) AS cex  FROM examination_detail WHERE ex_d_header_id ='$ex_id'";
          $resultit = $dbc->query($sqlit);
          if ($resultit->num_rows > 0) {
            while($rowit = $resultit->fetch_assoc()){
              $numberitem =(int)$rowit["cex"];
              echo(" <label  class='col-sm-2 control-label'> ข้อที่ ".($numberitem+1)." </label>");
            }
          }
          ?>
        </div>
      </div>
      <div class="row">
        <div class="col-lg-12">
          <form class="form-horizontal" action="" id="myform1" name="frmMain" method="post" onkeypress="return event.keyCode != 13;" >

            <div class="row">
              <div class="col-sm-12 ">
                <label for="inputEmail3" class="col-sm-2 control-label">คำถาม<t style="color: #ff0000;">*</t></label>
                <div class="col-sm-8 form-group ">
                  <textarea row="6" class="form-control css-require" id="exampleInputEmail2" placeholder="คำถาม" name="txtex_detail"></textarea>
                </div>
              </div>
            </div>

            <div class="row">
              <div class="col-sm-12 ">
                <label for="inputEmail3" class="col-sm-3 control-label">A<t style="color: #ff0000;">*</t></label>
                <div class="col-sm-7 form-group ">
                  <input type="text"class="form-control css-require" id="exampleInputEmail2" placeholder="คำตอบ A" name="txtex_s_A">
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-sm-12 ">
                <label for="inputEmail3" class="col-sm-3 control-label">B<t style="color: #ff0000;">*</t></label>
                <div class="col-sm-7 form-group ">
                  <input type="text" class="form-control css-require" id="exampleInputEmail2" placeholder="คำตอบ B" name="txtex_s_B">
                </div>
              </div>
            </div>

            <div class="row">
              <div class="col-sm-12 ">
                <label for="inputEmail3" class="col-sm-3 control-label">C<t style="color: #ff0000;">*</t></label>
                <div class="col-sm-7 form-group ">
                  <input type="text" class="form-control css-require" id="exampleInputEmail2" placeholder="คำตอบ C" name="txtex_s_C">
                </div>
              </div>
            </div>

            <div class="row">
              <div class="col-sm-12 ">
                <label for="inputEmail3" class="col-sm-3 control-label">D<t style="color: #ff0000;">*</t></label>
                <div class="col-sm-7 form-group ">
                  <input type="text" class="form-control css-require" id="exampleInputEmail2" placeholder="คำตอบ D" name="txtex_s_D">
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-sm-12 form-group">
                <label for="inputEmail3" class="col-sm-4 control-label">จงเลือกคำตอบที่ถูกต้อง<t style="color: #ff0000;">*</t></label>
                <div class="radio col-sm-1">
                  <label ><input type="radio" checked class="css-require" id="exampleInputEmail2" name="radcheap" value="A"> A</label>
                </div>
                <div class="radio col-sm-1">
                  <label ><input type="radio"  class="css-require" id="exampleInputEmail2" name="radcheap" value="B" > B</label>
                </div>
                <div class="radio col-sm-1">
                  <label ><input type="radio"  class="css-require" id="exampleInputEmail2" name="radcheap" value="C" > C</label>
                </div>
                <div class="radio col-sm-1">
                  <label ><input type="radio"  class="css-require" id="exampleInputEmail2" name="radcheap" value="D" > D</label>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-sm-12 ">
                <?php //$ex_numberExams
                if(((int)$ex_numberExams-(int)$numberitem)>0){
                  ?>
                  <label for="inputEmail3" class="col-sm-8 control-label"></label>
                  <button type="button" onclick="window.location.reload()" class="btn btn-default" data-dismiss="modal">ยกเลิก</button>
                  <button type="submit" class="btn btn-primary" name="subInsersubitem">บันทึก</button>
                  <?php 
                }else{
                  ?>
                  <label for="inputEmail3" class="col-sm-8 control-label">บันทึกครบแล้ว</label>
                  <?php
                }
                ?>

              </div>
            </div>
            <br>
          </form>
        </div>
      </div>
      <div class="row">
        <div class="col-lg-12">
          <?php
          if(((int)$ex_numberExams-(int)$numberitem)>0){
            echo(" <h4>ข้อสอบ จำนวน ".($numberitem) ." ข้อ เหลืออีก ".($ex_numberExams-$numberitem)."  ข้อ</h4> ");
          }else{

            echo(" <h4>ข้อสอบ จำนวน ".($numberitem) ." ข้อ บันทึกครบแล้ว</h4> ");
          }
          ?>
        </div>
      </div>
      <div class="list-group">
        <?php 
        $sql_dl=" SELECT ed.ex_d_id,ed.ex_d_header_id,ed.ex_d_title, es.ex_s_id,es.ex_s_A,es.ex_s_B,es.ex_s_C,es.ex_s_D,es.ex_s_cheap FROM examination_detail ed,examination_subitem es WHERE ed.ex_d_id = es.ex_s_d_id AND ex_d_header_id ='$ex_id' ";
        $result_dl = $dbc->query($sql_dl);
        $l=1;
        if ($result_dl->num_rows > 0) {
          while($row_dl = $result_dl->fetch_assoc()){
            ?>
            <a href="#"  data-toggle="modal" data-target="#<?php echo $row_dl['ex_d_id'];?>" data-whatever="@mdo" class="list-group-item" >
              <h4 class="list-group-item-heading"><?php echo $l++; ?>.<?php echo $row_dl["ex_d_title"]; ?></h4>
              <p  class="list-group-item-text">&nbsp;&nbsp; A.
                <?php
                echo $row_dl["ex_s_A"]; 
                if($row_dl["ex_s_cheap"]=="A"){
                  ?>
                  <i style="color: #00ff40;" class="glyphicon glyphicon-ok"></i>
                  <?php
                }
                ?> </p>
                <p class="list-group-item-text">&nbsp;&nbsp; B.
                  <?php 
                  echo $row_dl["ex_s_B"];
                  if($row_dl["ex_s_cheap"]=="B"){
                    ?>
                    <i style="color: #00ff40;" class="glyphicon glyphicon-ok"></i>
                    <?php
                  }
                  ?>  
                </p>
                <p class="list-group-item-text">&nbsp;&nbsp; C.
                  <?php
                  echo $row_dl["ex_s_C"];
                  if($row_dl["ex_s_cheap"]=="C"){
                    ?>
                    <i style="color: #00ff40;" class="glyphicon glyphicon-ok"></i>
                    <?php
                  }
                  ?>  </p>
                  <p class="list-group-item-text">&nbsp;&nbsp; D.
                    <?php 
                    echo $row_dl["ex_s_D"]; 
                    if($row_dl["ex_s_cheap"]=="D"){
                      ?>
                      <i style="color: #00ff40;" class="glyphicon glyphicon-ok"></i>
                      <?php
                    }
                    ?> </p>
                  </a>
                  <div class="modal" id="<?php echo $row_dl['ex_d_id'];?>" 
                            tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
                            <br><br><br><br><br><br><br><br><br><br><br><br> 
                            <div class="modal-dialog modal-sm" role="document">
                              <div class="modal-content">
                                <div class="modal-header">
                                  <a href=""  class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span></a>
                                    <h4 class="modal-title" id="exampleModalLabel">เมนู</h4>
                                  </div>
                                  <div class="modal-body">
                                    <a href="editExDetail.php?Edit_ex_D_Id=<?=$row_dl["ex_d_id"];?>" class="btn btn-success"> แก้ไขข้อมูล</a>
                                    <a href="editExDetail.php?dleteEx_id=<?=$row_dl["ex_d_id"];?>&dleteEx_s_id=<?=$row_dl["ex_s_id"];?>&ex_header_id=<?=$row_dl["ex_d_header_id"];?>" class="btn btn-danger"> &nbsp;ลบข้อมูล&nbsp;</a>
                                      <a href="" class="btn btn-default" data-dismiss="modal" aria-label="Close">&nbsp;ยกเลิก&nbsp;</a>
                                  </div>
                                </div>
                              </div>
                            </div>
                  <?php
                }
              }
              ?>

            </div>

          </div>
        </div>
        
        <?php
        if(isset($_POST['subInsersubitem'])){
          $ex_d_title = $_POST['txtex_detail'];
          $ex_s_A =$_POST['txtex_s_A'];
          $ex_s_B=$_POST['txtex_s_B'];
          $ex_s_C=$_POST['txtex_s_C'];
          $ex_s_D=$_POST['txtex_s_D'];
          $ex_s_cheap=$_POST['radcheap'];
          $ex_d_Id ="";

          $sql_d=" SELECT MAX(ex_d_id)+1 AS id FROM examination_detail ";
          $result_d = $dbc->query($sql_d);
          if ($result_d->num_rows > 0) {
            while($row_d = $result_d->fetch_assoc()){
              if($row_d["id"] =="" ){
                $ex_d_Id = 1;
              }else{
                $ex_d_Id = $row_d["id"];
              }
            }
          }
          $stmt_d = $dbc->prepare("INSERT INTO examination_detail(ex_d_id,ex_d_header_id,ex_d_title) VALUES(?,?,?)");
          $stmt_d->bind_param("sss",$ex_d_Id,$ex_id,$ex_d_title);
          $stmt_d->execute();

          $stmt_S = $dbc->prepare("INSERT INTO examination_subitem(ex_s_d_id, ex_s_A,ex_s_B,ex_s_C,ex_s_D,ex_s_cheap) VALUES(?,?,?,?,?,?)");
          $stmt_S->bind_param("ssssss",$ex_d_Id,$ex_s_A,$ex_s_B,$ex_s_C,$ex_s_D,$ex_s_cheap);
          $stmt_S->execute();

          ?>
          <div class="container">
            <div class="modal show" id="myModal" role="dialog">
              <div class="modal-dialog">

                <!-- Modal content-->
                <div class="modal-content">
                  <div class="modal-header">
                    <a href="examinationDetail.php?exId=<?=$ex_id;?>" type="button" class="close"   data-dismiss="modal">&times;</a>
                    <h4 class="modal-title">สำเร็จ</h4>
                  </div>
                  <div class="modal-body">
                    <p>บันทึกข้อมูลของสำเร็จ .</p>
                  </div>
                  <div class="modal-footer">
                    <a type="button" href="examinationDetail.php?exId=<?=$ex_id;?>"  class="btn btn-default"  data-dismiss="modal">Close</a>
                  </div>
                </div>

              </div>
            </div>
          </div>
          <?php
        }

        ?>
        <script src="js/jquery.js"></script>
        <script src="js/checkforms.js"></script>
        <script src="js/inputdate.js"></script>
        <script src="js/jquery.datetimepicker.js"></script>
        <script src="build/jquery.datetimepicker.full.js"></script>
      </body>
      </html>