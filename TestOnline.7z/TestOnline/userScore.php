
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>เพิ่มข้อสอบ</title>
  <style type="text/css">
    .b{
      color: #BDBDBD;
      margin-left: 0%;
      font-size: 12px;
    }
  </style>
</head>
<body>

  <?php
  $date = date("Y-m-d");
  function DateThai($strDate)
  {
    $strYear = date("Y",strtotime($strDate))+543;
    $strMonth= date("n",strtotime($strDate));
    $strDay= date("j",strtotime($strDate));
    $strHour= date("H",strtotime($strDate));
    $strMinute= date("i",strtotime($strDate));
    $strSeconds= date("s",strtotime($strDate));
    $strMonthCut = Array("","ม.ค.","ก.พ.","มี.ค.","เม.ย.","พ.ค.","มิ.ย.","ก.ค.","ส.ค.","ก.ย.","ต.ค.","พ.ย.","ธ.ค.");
    $strMonthThai=$strMonthCut[$strMonth];
    return "$strDay $strMonthThai $strYear, $strHour:$strMinute";
  }

  ?>
  <div id="wrapper">
    <?php
    require_once("mysqlconnect.php");
    include('manu.php');
    ?>
    <div id="page-wrapper">
     <div class="container-fluid">
      <div class="row">
        <div class="col-lg-12">
          <h1 class="page-header">
            ผลคะแนนสอบ
          </h1>
        </div>
      </div>

      <div class="row">
        <div class="col-lg-12">
          <form class="form-horizontal" action="" id="myform1" name="frmMain" method="post" onkeypress="return event.keyCode != 13;" >
            <div class="input-group">
              <input type="text" name="txtex_id" class="form-control" placeholder="ระบุรหัสชุดข้อสอบ...">
              <span class="input-group-btn">
                <button type="submis" class="btn btn-default" name="sechiud" type="button">ค้นหา!</button>
              </span>
            </div>
          </form>
        </div>
      </div>

      <?php
      $IDUsers =$_SESSION['u_id'];
      if(isset($_POST['sechiud'])){
        $ex_id = $_POST['txtex_id'];
        ?>
        <div class="row">
         <div class="list-group">
          <?php 
          $sql_dl="SELECT e.IDExamScore,e.ExamScore,e.IDExamination,e.IDUsers,e.ExamDate,eh.ex_name,eh.ex_course,eh.ex_numberExams FROM examscore e, examination_header eh WHERE e.IDExamination = eh.ex_id AND e.IDUsers =  '$IDUsers' AND e.IDExamination ='$ex_id'  order by e.ExamDate ASC ";
          $result_dl = $dbc->query($sql_dl);
          $l=1;
          if ($result_dl->num_rows > 0) {
            while($row_dl = $result_dl->fetch_assoc()){
              ?>
              <a  class="list-group-item">
                <h4 class="list-group-item-heading"><?php echo $l++.". ".$row_dl["ex_name"]; ?></h4>
                <p  class="list-group-item-text"><?php echo "<b>รายวิชา </b> ".$row_dl["ex_course"]; ?></p>
                <p  class="list-group-item-text"><?php echo "<b>รหัสชุดข้อสอบ </b> ".$row_dl["IDExamination"]; ?></p>
                <p  class="list-group-item-text"><?php echo "<b>จำนวนข้อสอบ </b> ".$row_dl["ex_numberExams"] ." ข้อ"; ?> 
                <?php echo "<b>ผลการสอบ </b> " ;
                $numberExams =($row_dl["ex_numberExams"] / 2);
                if($row_dl["ExamScore"] < $numberExams ){
                  echo "<font size='3' color='red'> สอบตก </font> " ;
                } else{
                  echo "<font size='3' color='green'> สอบผ่าน </font> " ;
                }
                ?>
              </p>
              <p  class="list-group-item-text">
                <?php echo "<b>คะแนนที่ได้ </b> ".$row_dl["ExamScore"]. " คะแนน"; ?> <?php echo "<b>วันที่สอบ </b> ".DateThai($row_dl["ExamDate"]) ; ?>
              </p>
            </a>
            <?php
          }
        }else{
          echo("<h3 class='page-header'> ไม่พบคะแนนการทำข้อสอบ </h3>");
        }
        ?>
      </div>
    </div>

    <?php
  }else{
   $ex_id = $_POST['txtex_id'];
   ?>
   <br>
   <div class="row">
     <div class="list-group">
      <?php 
      $sql_dl="SELECT e.IDExamScore,e.ExamScore,e.IDExamination,e.IDUsers,e.ExamDate,eh.ex_name,eh.ex_course,eh.ex_numberExams FROM examscore e, examination_header eh WHERE e.IDExamination = eh.ex_id AND e.IDUsers =  '$IDUsers' order by e.ExamDate ASC ";
      $result_dl = $dbc->query($sql_dl);
      $l=1;
      if ($result_dl->num_rows > 0) {
        while($row_dl = $result_dl->fetch_assoc()){
          ?>
          <a  class="list-group-item">
            <h4 class="list-group-item-heading"><?php echo $l++.". ".$row_dl["ex_name"]; ?></h4>
            <p  class="list-group-item-text"><?php echo "<b>รายวิชา </b> ".$row_dl["ex_course"]; ?></p>
            <p  class="list-group-item-text"><?php echo "<b>รหัสชุดข้อสอบ </b> ".$row_dl["IDExamination"]; ?></p>
            <p  class="list-group-item-text"><?php echo "<b>จำนวนข้อสอบ </b> ".$row_dl["ex_numberExams"] ." ข้อ"; ?> <?php echo "<b>ผลการสอบ </b> " ;
            $numberExams =($row_dl["ex_numberExams"] / 2);
            if($row_dl["ExamScore"] < $numberExams ){
              echo "<font size='3' color='red'> สอบตก </font> " ;
            } else{
              echo "<font size='3' color='green' >สอบผ่าน </font> " ;
            }
            ?>
          </p>
          <p  class="list-group-item-text"><?php echo "<b>คะแนนที่ได้ </b> ".$row_dl["ExamScore"]. " คะแนน"; ?> <?php echo "<b>วันที่สอบ </b> ".DateThai($row_dl["ExamDate"]) ; ?></p>
          <br>

        </a>
        <?php
      }
    }else{
      echo("<h3 class='page-header'> ไม่พบคะแนนการทำข้อสอบ </h3>");
    }
    ?>
  </div>
</div>

<?php
}
?>
</div>
</div>
</div>
</div>
<script src="js/jquery.js"></script>
<script src="js/checkforms.js"></script>
<script src="js/inputdate.js"></script>
<script src="js/jquery.datetimepicker.js"></script>
<script src="build/jquery.datetimepicker.full.js"></script>
</body>
</html>