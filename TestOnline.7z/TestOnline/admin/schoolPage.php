
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>หน้าหลัก</title>
  <style type="text/css">
    .imghead{}

    img{
      width: 250px;
      height: 250px;
      margin-top: 2px;
      text-align: center;
      -moz-box-shadow: 5px 5px 5px #fff;  
      -webkit-box-shadow: 5px 5px 5px #fff;  
      box-shadow: 5px 5px 5px #fff;

    }
    .b{
      color: #BDBDBD;
      margin-left: 0%;
      font-size: 12px;
    }

    .comment{
      margin-left: 20px;
    }
    .comment h4{
      margin-left: 10px;
      font-size: 11px;
      color: #424242;

    }
    .imga{
      text-align: center;
      width: 180px;
      height: 100px;
      margin-left: 5%;
    }
    .scrollbar10{
      width:100%;
      height:400px;
      overflow-y:scroll;


    }
    #ex10::-webkit-scrollbar{
      width:10px;


    } 
    #ex10::-webkit-scrollbar-thumb{

      border-radius:10px;
    }
    #ex10::-webkit-scrollbar-thumb:hover{
      background-color:#90CAF9;
      border:10px solid #90CAF9;

    }
    #ex10::-webkit-scrollbar-thumb:active{
      background-color:#BBDEFB;
      border:10px solid #BBDEFB;

    } 
    #ex10::-webkit-scrollbar-track{
      border:2px ;
      border-radius:10px;

    </style>

  </head>
  <body>

    <?php
    $date = date("Y-m-d");
    function getNumDay($d1,$d2){
      $dArr1    = preg_split("/-/", $d1);
      list($year1, $month1, $day1) = $dArr1;
      $Day1 =  mktime(0,0,0,$month1,$day1,$year1);

      $dArr2    = preg_split("/-/", $d2);
      list($year2, $month2, $day2) = $dArr2;
      $Day2 =  mktime(0,0,0,$month2,$day2,$year2);

      return round(abs( $Day2 - $Day1 ) / 86400 )+1;
    }

    ?>
    <div id="wrapper">
     <?php
     require_once("mysqlconnect.php");
     include('manu.php');
     ?>
     <div id="page-wrapper">
       <div class="container-fluid">
        <!-- Page Heading -->
        <div class="row">

          <div class="col-lg-12">
            <h1 class="page-header">
              รายชื่อโรงเรียน
            </h1>
            <ol class="breadcrumb">
              <li>
                <i class="fa fa-dashboard"></i>  <a href="index.php">ระบบสอบออนไลน์</a>
              </li>
              <li class="active">
                <i class="glyphicon glyphicon-th"></i> รายชื่อโรงเรียน
              </li>

              <li>
                <i class="
                glyphicon glyphicon-plus-sign"></i>  <a href='#' data-toggle="modal" data-target="#inschool" data-whatever="@mdo">เพิ่มรายชื่อโรงเรียน</a>
              </li>
            </ol>
          </div>
        </div>
        <div class="row">
          <div class="col-lg-12 a" >
            <form class="form-inline" action="schoolPage.php" method="get">
              <div class="form-group">
                <h4 class="form-control-static">ชื่อโรงเรียน</h4>
                <input type="text" class="form-control" placeholder="Search" name="SearchName">
                <button type="submit" class="btn btn-default" name="Search"><i class="glyphicon glyphicon-search
                  "></i></button>
                </div>
              </form>
            </div>
          </div>
          <div class="row">
            <br>
            <div class="col-lg-12 scrollbar table-responsive" id="ex3">
              <table class="table table-bordered table-hover" >
                <thead>
                  <tr>
                    <th>#</th>
                    <th>ชื่อโรงเรียน</th>
                    <th>อำเภอ</th>
                    <th>จังหวัด</th>
                    <th></th>

                  </tr>
                </thead>
                <tbody class="">
                  <?php
                  if(!isset($_GET['Search'])){
                    $sql=" SELECT s.IDSchool,s.NameSchool,s.IDDistrict, d.NameDistrict,p.ProvinceName FROM school s, district d ,province p WHERE s.IDDistrict = d.IDDistrict AND d.IDProvince = p.IDProvince ORDER BY NameSchool ASC";
                    $result = $dbc->query($sql);
                    $l=1;
                    if ($result->num_rows > 0) {
                      while($row = $result->fetch_assoc()) {
                        ?>
                        <tr>
                          <td><?php echo $l++; ?></td>
                          <td><?php echo $row['NameSchool'];?></td>
                          <td> <?php echo $row["NameDistrict"];?></td>
                          <td><?php echo $row["ProvinceName"];?></td>
                          <td>
                            <div class="form-group " >

                              <form  method="get" action = "" onkeypress="return event.keyCode != 13;" >
                                <a  href='editSchool.php?IDSchool=<?=$row['IDSchool'];?>' class="btn btn-success"> <i class="glyphicon glyphicon-edit"></i> แก้ไข</a>
                                 <input type="hidden" id="IDSchool" name="IDSchool" value="<?=$row['IDSchool'];?>">
                                <button type="submit" name="bntIDSchool" class="btn btn-info"><i class="glyphicon glyphicon-remove-circle" ></i> ลบ </button>
                              </form>
                            </div>
                          </td>
                        </tr>
                        <?php
                      }
                    }
                  }
                  if(isset($_GET['Search'])){
                    $school_name = $_GET['SearchName'];
                    $sql=" SELECT s.IDSchool,s.NameSchool,s.IDDistrict, d.NameDistrict,p.ProvinceName FROM school s, district d ,province p WHERE s.IDDistrict = d.IDDistrict AND d.IDProvince = p.IDProvince AND s.NameSchool LIKE '$school_name%' ";
                    $result = $dbc->query($sql);
                    $l=1;
                    if ($result->num_rows > 0) {
                      while($row = $result->fetch_assoc()) {
                        ?>
                        <tr>
                          <td><?php echo $l++; ?></td>
                          <td><?php echo $row['NameSchool'];?></td>
                          <td><?php echo $row['NameDistrict'];?></td>
                          <td><?php echo $row['ProvinceName'];?></td>
                          <td>
                            <div class="form-group ">
                              <form  method="post" action = "" onkeypress="return event.keyCode != 13;" >
                                <a  href='editSchool.php?IDSchool=<?=$row['IDSchool'];?>'class="btn btn-success"> <i class="glyphicon glyphicon-edit"></i> แก้ไข</a>
                                <button type="submit" name="bntIDSchool" class="btn btn-info"><i class="glyphicon glyphicon-remove-circle" ></i> ลบ </button>
                              </form>
                            </div>
                          </td>
                        </tr>
                        <?php
                      }
                    }
                  }
                  ?>
                </tbody>
              </table>
            </div>

          </div>
        </div>
      </div>


      <?php
      if(isset($_POST['bntInSchool'])){
        $schoolName = $_POST['txtNameSchool'];
        $District = $_POST['district'];
        $stmt = $dbc->prepare("INSERT INTO school (NameSchool,  IDDistrict) VALUES(?,?)");
        $stmt->bind_param("ss",$schoolName,$District);
        $stmt->execute();
        ?>
        <div class="container">
          <div class="modal show" id="myModal" role="dialog">
            <div class="modal-dialog">

              <!-- Modal content-->
              <div class="modal-content">
                <div class="modal-header">
                  <a href="schoolPage.php" type="button" class="close"  onclick = "$('.modal').removeClass('show').addClass('fade');" data-dismiss="modal">&times;</a>
                  <h4 class="modal-title">สำเร็จ</h4>
                </div>
                <div class="modal-body">
                  <p>สามารถเพิ่มข้อมูล <?php echo $schoolName ; ?>  สำเร็จ.</p>
                </div>
                <div class="modal-footer">
                  <a type="button" href="schoolPage.php"  class="btn btn-default" onclick = "$('.modal').removeClass('show').addClass('fade');" data-dismiss="modal">Close</a>
                </div>
              </div>

            </div>
          </div>
        </div>
        <?php
      }
      ?>

      <?php
      //ลบ
      if(isset($_GET['bntIDSchool'])){
        $IDSchool = $_GET['IDSchool'];
        $delete = $dbc->prepare("DELETE FROM school WHERE IDSchool = ?");
        $delete->bind_param("s",$IDSchool);
        $delete->execute();
        ?>
        <div class="container">
          <div class="modal show" id="myModal" role="dialog">
            <div class="modal-dialog">

              <!-- Modal content-->
              <div class="modal-content">
                <div class="modal-header">
                  <a href="schoolPage.php" type="button" class="close"  onclick = "$('.modal').removeClass('show').addClass('fade');" data-dismiss="modal">&times;</a>
                  <h4 class="modal-title">ลบสำเร็จ</h4>
                </div>
                <div class="modal-body">
                  <p>สามารถลบข้อมูลสำเร็จ.</p>
                </div>
                <div class="modal-footer">
                  <a type="button" href="schoolPage.php"  class="btn btn-default" onclick = "$('.modal').removeClass('show').addClass('fade');" data-dismiss="modal">Close</a>
                </div>
              </div>

            </div>
          </div>
        </div>
        <?php
      }
      ?>
      <div class="modal fade" id="inschool" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
        <div class="rrr" >
          <br> <br> <br> <br>
          <br> 
        </div>
        <div class="top_a"></div>
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
              <h4 class="modal-title" id="exampleModalLabel">เพิ่มชื่อโรงเรียน</h4>
            </div>
            <div class="modal-body">

              <form  method="post" action = "" onkeypress="return event.keyCode != 13;" id="myform1"enctype="multipart/form-data" >
                <div class="form-group ">
                  <label for="exampleInputEmail2">ชื่อโรงเรียน</label>
                  <input type="text" class="form-control css-require" id="exampleInputEmail2" placeholder="ชื่อโรงเรียน" name="txtNameSchool">
                </div>

                <div class="form-group">
                  <label for="exampleInputEmail2">จังหวัด</label>
                  <select class="form-control css-require" name="Rovince" id="Rovince">
                    <option value="">เลือก</option>
                    <?php
                    $sql=" SELECT IDProvince,ProvinceName FROM province";
                    $result = $dbc->query($sql);
                    if ($result->num_rows > 0) {
                      while($row = $result->fetch_assoc()) {?>
                        <option value="<?php echo $row['IDProvince'];?>"><?php echo $row['ProvinceName'];?>
                      </option>
                      <?php
                    }
                  }
                  ?>
                </select> 
              </div>
              <div class="form-group">
                <label for="exampleInputEmail2">อำเภอ</label>
                <select class="form-control css-require" name="district" id="district">
                  <option value="">เลือกรายการ</option>
                </select>

              </div>

              <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">ยกเลิก</button>
                <button type="submit" class="btn btn-primary" name="bntInSchool">ยืนยัน</button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>

    <script src="../js/jquery.js"></script>
    <script src="../js/checkforms.js"></script>
    <script src="../js/inputdate.js"></script>
    <script src="../js/jquery.datetimepicker.js"></script>
    <script src="../build/jquery.datetimepicker.full.js"></script>
    <script type="text/javascript">
      $(function(){
          // เมื่อเปลี่ยนค่าของ select id เท่ากับ list1
          $("select#Rovince").change(function(){  

               // ส่งค่า ตัวแปร list1 มีค่าเท่ากับค่าที่เลือก ส่งแบบ get ไปที่ไฟล์ data_for_list2.php

               $.get("Mode/selectDistrict.php",{
                Rovince:$(this).val()
               },function(data){ // คืนค่ากลับมา
                 //alert("yyyy");
                $("select#district").html(data);  // นำค่าที่ได้ไปใส่ใน select id เท่ากับ list2
              });
             });     
          
        });
      </script> 
      <script type="text/javascript">
        $(window).on('load',function(){
          $('#inschool').modal('show');
        });
      </script>

    </body>
    </html>