
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>หน้าหลัก</title>
  <style type="text/css">
    .imghead{}

    img{
      width: 250px;
      height: 250px;
      margin-top: 2px;
      text-align: center;
      -moz-box-shadow: 5px 5px 5px #fff;  
      -webkit-box-shadow: 5px 5px 5px #fff;  
      box-shadow: 5px 5px 5px #fff;

    }
    .b{
      color: #BDBDBD;
      margin-left: 0%;
      font-size: 12px;
    }

    .comment{
      margin-left: 20px;
    }
    .comment h4{
      margin-left: 10px;
      font-size: 11px;
      color: #424242;

    }
    .imga{
      text-align: center;
      width: 180px;
      height: 100px;
      margin-left: 5%;
    }
    .scrollbar10{
      width:100%;
      height:400px;
      overflow-y:scroll;


    }
    #ex10::-webkit-scrollbar{
      width:10px;


    } 
    #ex10::-webkit-scrollbar-thumb{

      border-radius:10px;
    }
    #ex10::-webkit-scrollbar-thumb:hover{
      background-color:#90CAF9;
      border:10px solid #90CAF9;

    }
    #ex10::-webkit-scrollbar-thumb:active{
      background-color:#BBDEFB;
      border:10px solid #BBDEFB;

    } 
    #ex10::-webkit-scrollbar-track{
      border:2px ;
      border-radius:10px;

    </style>

  </head>
  <body>

    <?php
    $date = date("Y-m-d");
    function getNumDay($d1,$d2){
      $dArr1    = preg_split("/-/", $d1);
      list($year1, $month1, $day1) = $dArr1;
      $Day1 =  mktime(0,0,0,$month1,$day1,$year1);

      $dArr2    = preg_split("/-/", $d2);
      list($year2, $month2, $day2) = $dArr2;
      $Day2 =  mktime(0,0,0,$month2,$day2,$year2);

      return round(abs( $Day2 - $Day1 ) / 86400 )+1;
    }

    ?>
    <div id="wrapper">
     <?php
     require_once("mysqlconnect.php");
     include('manu.php');
     ?>

     <?php
     // ui เพิ่ม
     if(isset($_GET["u_id"])){
      $u_id =$_REQUEST["u_id"];
      $u_userName  ="";
      $u_password ="";
      $u_firstName="";
      $u_lastName="";
      $u_address="";
      $IDCanton="";
      $IDDistrict="";
      $IDProvince="";
      $u_email="";
      $u_tell="";
      $u_schoolID="";
      $u_type="";
      $NameDistrict="";
      $NameCanton="";
      $ProvinceName="";
      $NameSchool="";
      $sql=" SELECT U.u_userName,U.u_password,U.u_id,U.u_firstName,U.u_lastName,U.u_address,U.IDCanton,U.IDDistrict,U.IDProvince,U.u_email,U.u_tell,U.u_schoolID,U.u_type,D.NameDistrict,C.NameCanton,P.ProvinceName,S.NameSchool FROM users U, district D ,canton C, province P, school S where U.IDCanton = C.IDCanton AND U.IDDistrict = D.IDDistrict AND U.IDProvince = P.IDProvince AND U.u_schoolID = S.IDSchool AND U.u_id ='$u_id'";
      $result = $dbc->query($sql);
      $l=1;
      if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
         $u_id =$row['u_id'];
         $u_password =$row['u_password'];
         $u_userName=$row['u_userName'];
         $u_firstName=$row['u_firstName'];
         $u_lastName=$row['u_lastName'];
         $u_address=$row['u_address'];
         $IDCanton=$row['IDCanton'];
         $IDDistrict=$row['IDDistrict'];
         $IDProvince=$row['IDProvince'];
         $u_email=$row['u_email'];
         $u_tell=$row['u_tell'];
         $u_schoolID=$row['u_schoolID'];
         $u_type=$row['u_type'];
         $NameDistrict=$row['NameDistrict'];
         $NameCanton=$row['NameCanton'];
         $ProvinceName=$row['ProvinceName'];
         $NameSchool=$row['NameSchool'];
       }
     }
     ?>
     <div id="page-wrapper">
       <div class="container-fluid">
        <div class="row">
          <div class="col-lg-12">
            <h1 class="page-header">
              แก้ไขข้อมูลผู้ใช้งาน
            </h1>
            <ol class="breadcrumb">
              <li>
                <i class="fa fa-dashboard"></i>  <a href="index.php">ระบบสอบออนไลน์</a>
              </li>
              <li class="active">
                <i class="glyphicon glyphicon-th"></i> แก้ไขข้อมูลผู้ใช้งาน
              </li>


            </ol>
          </div>
        </div>
        <form class="form-horizontal" action="" id="myform1" name="frmMain" method="post" onkeypress="return event.keyCode != 13;" >
          <div class="form-group">
            <div class="col-sm-12 ">
             <label for="inputEmail3" class="col-sm-2 control-label">ชื่อ</label>
             <div class="col-sm-4 form-group ">
               <input type="text" class="form-control css-require" id="exampleInputEmail2" placeholder="นาย/นางสาว" name="txtfirstName" value="<?php echo($u_firstName);?>">
             </div>
             <div class="col-sm-4  form-group " >
               <input type="text" class="form-control css-require " id="exampleInputEmail2" placeholder="นามสกุล" name="txtlastName" value="<?php echo($u_lastName);?>">
             </div>

           </div>
         </div>
         <?php 
         if($u_id == $_SESSION['u_id']){?>
           <div class="form-group">
            <div class="col-sm-12 ">
             <label for="inputEmail3" class="col-sm-2 control-label">UserName</label>
             <div class="col-sm-8 form-group">
              <input type="text" class="form-control css-require" id="exampleInputEmail2" placeholder="UserName" name="txtUserName" value="<?php echo($u_userName);?>">
            </div>
          </div>
        </div>

        <div class="form-group">
          <div class="col-sm-12 ">
           <label for="inputEmail3" class="col-sm-2 control-label">Password</label>
           <div class="col-sm-8 form-group">
             <input type="password" class="form-control css-require" id="exampleInputEmail2" placeholder="****" name="txtPassword" value="<?php echo($u_password);?>">
           </div>
         </div>
       </div>
       <?php

     }
     ?>
     <div class="form-group">
      <div class="col-sm-12 ">
       <label for="inputEmail3" class="col-sm-2 control-label">ที่อยู่</label>
       <div class="col-sm-8 form-group">
         <input type="text" class="form-control css-require" id="exampleInputEmail2" placeholder="บ้านเลขที่" name="txtAddess" value="<?php echo($u_address);?>">
       </div>
     </div>
   </div>

   <div class="form-group">
    <div class="col-sm-12 ">
      <label for="inputEmail3" class="col-sm-2 control-label">จังหวัด</label>
      <div class="col-sm-4 form-group">
       <select class="form-control css-require" name="Rovince" id="Rovince">
        <option value="">เลือก</option>
        <?php
        $sql=" SELECT IDProvince,ProvinceName FROM province";
        $result = $dbc->query($sql);
        if ($result->num_rows > 0) {
          while($row = $result->fetch_assoc()) {
            if($row['IDProvince'] == $IDProvince ){
              ?>
              <option selected value="<?php echo $row['IDProvince'];?>"><?php echo $row['ProvinceName'];?>
            </option>
            <?php
          }else{
            ?>
            <option  value="<?php echo $row['IDProvince'];?>"><?php echo $row['ProvinceName'];?>
          </option>
          <?php
        }
      }
    }
    ?>
  </select> 
</div>
</div>
</div>

<div class="form-group">
  <div class="col-sm-12 ">
    <label for="inputEmail3" class="col-sm-2 control-label">อำเภอ</label>
    <div class="col-sm-4 form-group">
     <select class="form-control css-require" name="district" id="district">
      <option value="<?php echo($IDDistrict); ?>"><?php echo($NameDistrict); ?></option>
    </select>
  </div>
</div>
</div>

<div class="form-group">
  <div class="col-sm-12 ">
    <label for="inputEmail3" class="col-sm-2 control-label">ตำบล</label>
    <div class="col-sm-4 form-group">
      <select class="form-control css-require" name="canton" id="canton">
        <option value="<?php echo($IDCanton); ?>"><?php echo($NameCanton); ?></option>
      </select>
    </div>
  </div>
</div>

<div class="form-group" style="display: none;">
  <div class="col-sm-12 ">
    <label for="inputEmail3" class="col-sm-2 control-label">สังกัดโรงเรียน</label>
    <div class="col-sm-4 form-group">
     <select class="form-control css-require" name="school" id="school">
       <option value="<?php echo($u_schoolID); ?>"><?php echo($NameSchool); ?></option>
     </select> 
   </div>
 </div>
</div>

<div class="form-group">
  <div class="col-sm-12 ">
    <label for="inputEmail3" class="col-sm-2 control-label">Email</label>
    <div class="col-sm-4 form-group">
      <input type="Email" class="form-control css-require" id="exampleInputEmail2" placeholder="Email" name="txtEmail"  value="<?php echo($u_email);?>">
    </div>
  </div>
</div>

<div class="form-group">
  <div class="col-sm-12 ">
    <label for="inputEmail3" class="col-sm-2 control-label">เบอร์โทรศัพท์</label>
    <div class="col-sm-4 form-group">
      <input type="tel" pattern="[0-9]{10}" required class="form-control css-require "
      id="exampleInputEmail2" placeholder="เบอร์โทร" name="txtphone"  value="<?php echo($u_tell);?>">

    </div>
  </div>
</div>

<div class="form-group">
  <div class="col-sm-12 ">
    <label for="inputEmail3" class="col-sm-2 control-label">สิทธ์เข้าใช้งาน</label>
    <div class="col-sm-4 form-group">
     <select class="form-control css-require" name="utype" id="utype" >
      <option value="<?php echo($u_type); ?>"><?php 
      if($u_type == "2"){
        echo("ผู้ดูแลระบบ");
      }else if($u_type == "1"){
        echo("อาจารย์"); 
      }else{
        echo("นักเรียน"); 
      }
      ?></option>
      <option value="0 ">นักเรียน</option>
      <option value="1" >อาจารย์ </option>
      <option value="2" >ผู้ดูแลระบบ </option>
    </select> 
  </div>
</div>
</div>
<div class="modal-footer">
  <button type="button" class="btn btn-default" data-dismiss="modal">ยกเลิก</button>
  <button type="submit" class="btn btn-primary" name="subUpdateUser">ยืนยัน</button>
</div>
</form>
</div>
</div>
</div>


<?php
//update
if(isset($_POST['subUpdateUser'])){
 $u_userNameUp = $u_userName;
 $u_passwordUp = $u_password;
 if($u_id == $_SESSION['u_id']){
  $u_userNameUp = $_POST['txtUserName'];
  $u_passwordUp = $_POST['txtPassword'];
}

$u_firstNameUp = $_POST['txtfirstName'];
$u_lastNameUp = $_POST['txtlastName'];
$u_addressUp = $_POST['txtAddess'];
$IDCantonUp = $_POST['canton'];
$IDDistrictUp = $_POST['district'];
$IDProvinceUp = $_POST['Rovince'];
$u_emailUp = $_POST['txtEmail'];
$u_tellUp = $_POST['txtphone'];
$u_schoolIDUp = $_POST['school'];
$u_typeUp = $_POST['utype'];
$stmt = $dbc->prepare("UPDATE users SET u_userName =? , u_password = ?,u_firstName=?,u_lastName=?,u_address=?,IDCanton=?,IDDistrict=?,IDProvince=?,u_email=?,u_tell=?, u_schoolID=?,u_type=? WHERE u_id = $u_id");
$stmt->bind_param("ssssssssssss",$u_userNameUp,$u_passwordUp,$u_firstNameUp,$u_lastNameUp,$u_addressUp,$IDCantonUp,$IDDistrictUp,$IDProvinceUp,$u_emailUp,$u_tellUp,$u_schoolIDUp,$u_typeUp);
$stmt->execute();

?>
<div class="container">
  <div class="modal show" id="myModal" role="dialog">
    <div class="modal-dialog">

      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <a href="userPage.php" type="button" class="close"  onclick = "$('.modal').removeClass('show').addClass('fade');" data-dismiss="modal">&times;</a>
          <h4 class="modal-title">สำเร็จ</h4>
        </div>
        <div class="modal-body">
          <p>สามารถแก้ไขข้อมูลของ <?php echo($u_firstName." ". $u_lastName) ?>  สำเร็จ.</p>
        </div>
        <div class="modal-footer">
          <a type="button" href="userPage.php"  class="btn btn-default" onclick = "$('.modal').removeClass('show').addClass('fade');" data-dismiss="modal">Close</a>
        </div>
      </div>

    </div>
  </div>
</div>
<?php

}


}else{
 ?>
 <div id="page-wrapper">
   <div class="container-fluid">
    <div class="row">
      <div class="col-lg-12">
        <h1 class="page-header">
          เพิ่มผู้ใช้งาน
        </h1>
        <ol class="breadcrumb">
          <li>
            <i class="fa fa-dashboard"></i>  <a href="index.php">ระบบสอบออนไลน์</a>
          </li>
          <li class="active">
            <i class="glyphicon glyphicon-th"></i> เพิ่มผู้ใช้งาน
          </li>


        </ol>
      </div>
    </div>
    <form class="form-horizontal" action="" id="myform1" name="frmMain" method="post" onkeypress="return event.keyCode != 13;" >
      <div class="form-group">
        <div class="col-sm-12 ">
         <label for="inputEmail3" class="col-sm-2 control-label">ชื่อ</label>
         <div class="col-sm-4 form-group ">
           <input type="text" class="form-control css-require" id="exampleInputEmail2" placeholder="นาย/นางสาว" name="txtfirstName">
         </div>
         <div class="col-sm-4  form-group " >
           <input type="text" class="form-control css-require " id="exampleInputEmail2" placeholder="นามสกุล" name="txtlastName">
         </div>

       </div>
     </div>
     <div class="form-group">
      <div class="col-sm-12 ">
       <label for="inputEmail3" class="col-sm-2 control-label">UserName</label>
       <div class="col-sm-8 form-group">
         <input type="text" class="form-control css-require" id="exampleInputEmail2" placeholder="UserName" name="txtUserName">
       </div>
     </div>
   </div>

   <div class="form-group">
    <div class="col-sm-12 ">
     <label for="inputEmail3" class="col-sm-2 control-label">Password</label>
     <div class="col-sm-8 form-group">
       <input type="password" class="form-control css-require" id="exampleInputEmail2" placeholder="****" name="txtPassword">
     </div>
   </div>
 </div>

 <div class="form-group">
  <div class="col-sm-12 ">
   <label for="inputEmail3" class="col-sm-2 control-label">ที่อยู่</label>
   <div class="col-sm-8 form-group">
     <input type="text" class="form-control css-require" id="exampleInputEmail2" placeholder="บ้านเลขที่" name="txtAddess">
   </div>
 </div>
</div>

<div class="form-group">
  <div class="col-sm-12 ">
    <label for="inputEmail3" class="col-sm-2 control-label">จังหวัด</label>
    <div class="col-sm-4 form-group">
     <select class="form-control css-require" name="Rovince" id="Rovince">
      <option value="">เลือก</option>
      <?php
      $sql=" SELECT IDProvince,ProvinceName FROM province";
      $result = $dbc->query($sql);
      if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {?>
          <option value="<?php echo $row['IDProvince'];?>"><?php echo $row['ProvinceName'];?>
        </option>
        <?php
      }
    }
    ?>
  </select> 
</div>
</div>
</div>

<div class="form-group">
  <div class="col-sm-12 ">
    <label for="inputEmail3" class="col-sm-2 control-label">อำเภอ</label>
    <div class="col-sm-4 form-group">
     <select class="form-control css-require" name="district" id="district">
      <option value="">เลือกรายการ</option>
    </select>
  </div>
</div>
</div>

<div class="form-group">
  <div class="col-sm-12 ">
    <label for="inputEmail3" class="col-sm-2 control-label">ตำบล</label>
    <div class="col-sm-4 form-group">
      <select class="form-control css-require" name="canton" id="canton">
        <option value="">เลือกรายการ</option>
      </select>
    </div>
  </div>
</div>

<div class="form-group" style="display: none;">
  <div class="col-sm-12 ">
    <label for="inputEmail3" class="col-sm-2 control-label">สังกัดโรงเรียน</label>
    <div class="col-sm-4 form-group">
     <select class="form-control" name="school" id="school">
      <option value="เลือกรายการ ">เลือกรายการ </option>
    </select> 
  </div>
</div>
</div>

<div class="form-group">
  <div class="col-sm-12 ">
    <label for="inputEmail3" class="col-sm-2 control-label">Email</label>
    <div class="col-sm-4 form-group">
      <input type="Email" class="form-control css-require" id="exampleInputEmail2" placeholder="Email" name="txtEmail">
    </div>
  </div>
</div>

<div class="form-group">
  <div class="col-sm-12 ">
    <label for="inputEmail3" class="col-sm-2 control-label">เบอร์โทรศัพท์</label>
    <div class="col-sm-4 form-group">
      <input type="tel" pattern="[0-9]{10}" required class="form-control css-require "
      id="exampleInputEmail2" placeholder="เบอร์โทร" name="txtphone">

    </div>
  </div>
</div>

<div class="form-group">
  <div class="col-sm-12 ">
    <label for="inputEmail3" class="col-sm-2 control-label">สิทธ์เข้าใช้งาน</label>
    <div class="col-sm-4 form-group">
     <select class="form-control css-require" name="utype" id="utype" >
      <option value="เลือกรายการ ">เลือกรายการ </option>
      <option value="2" selected>ผู้ดูแลระบบ </option>
    </select> 
  </div>
</div>
</div>
<div class="modal-footer">
  <button type="button" class="btn btn-default" data-dismiss="modal">ยกเลิก</button>
  <button type="submit" class="btn btn-primary" name="subInserUser">ยืนยัน</button>
</div>
</form>
</div>
</div>
</div>


<?php
//เพิ่มข้อมูล
if(isset($_POST['subInserUser'])){
  $u_userName = $_POST['txtUserName'];
  $u_password = $_POST['txtPassword'];
  $u_firstName = $_POST['txtfirstName'];
  $u_lastName = $_POST['txtlastName'];
  $u_address = $_POST['txtAddess'];
  $IDCanton = $_POST['canton'];
  $IDDistrict = $_POST['district'];
  $IDProvince = $_POST['Rovince'];
  $u_email = $_POST['txtEmail'];
  $u_tell = $_POST['txtphone'];
  $u_schoolID = $_POST['school'];
  $u_type = $_POST['utype'];
  $stmt = $dbc->prepare("INSERT INTO users (u_userName,u_password,u_firstName,u_lastName,u_address,IDCanton,IDDistrict,IDProvince,u_email,u_tell,u_schoolID,u_type) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)");
  $stmt->bind_param("ssssssssssss",$u_userName,$u_password,$u_firstName,$u_lastName,$u_address,$IDCanton,$IDDistrict,$IDProvince,$u_email,$u_tell,$u_schoolID,$u_type);
  $stmt->execute();
  
  ?>
  <div class="container">
    <div class="modal show" id="myModal" role="dialog">
      <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
          <div class="modal-header">
            <a href="userPage.php" type="button" class="close"  onclick = "$('.modal').removeClass('show').addClass('fade');" data-dismiss="modal">&times;</a>
            <h4 class="modal-title">สำเร็จ</h4>
          </div>
          <div class="modal-body">
            <p>สามารถเพิ่มข้อมูลของ <?php echo($u_firstName." ". $u_lastName) ?>  สำเร็จ.</p>
          </div>
          <div class="modal-footer">
            <a type="button" href="userPage.php"  class="btn btn-default" onclick = "$('.modal').removeClass('show').addClass('fade');" data-dismiss="modal">Close</a>
          </div>
        </div>

      </div>
    </div>
  </div>
  <?php

}
}
?>

<script src="../js/jquery.js"></script>
<script src="../js/checkforms.js"></script>
<script src="../js/inputdate.js"></script>
<script src="../js/jquery.datetimepicker.js"></script>
<script src="../build/jquery.datetimepicker.full.js"></script>
<script type="text/javascript">
  $(function(){
          // เมื่อเปลี่ยนค่าของ select id เท่ากับ list1
          $("select#Rovince").change(function(){  

               // ส่งค่า ตัวแปร list1 มีค่าเท่ากับค่าที่เลือก ส่งแบบ get ไปที่ไฟล์ data_for_list2.php

               $.get("Mode/selectDistrict.php",{
                Rovince:$(this).val()
               },function(data){ // คืนค่ากลับมา
                 //alert("yyyy");
                $("select#district").html(data);  // นำค่าที่ได้ไปใส่ใน select id เท่ากับ list2
              });
             });     
          
        });
      </script> 
      <script type="text/javascript">
        $(function(){
          // เมื่อเปลี่ยนค่าของ select id เท่ากับ list1
          $("select#district").change(function(){  

               // ส่งค่า ตัวแปร list1 มีค่าเท่ากับค่าที่เลือก ส่งแบบ get ไปที่ไฟล์ data_for_list2.php

               $.get("Mode/selectCanton.php",{
                district:$(this).val()
               },function(data){ // คืนค่ากลับมา
                 //alert("yyyy");
                $("select#canton").html(data);  // นำค่าที่ได้ไปใส่ใน select id เท่ากับ list2
              });
             });     
          
        });
      </script> 
      <script type="text/javascript">
        $(function(){
          // เมื่อเปลี่ยนค่าของ select id เท่ากับ list1
          $("select#district").change(function(){  

               // ส่งค่า ตัวแปร list1 มีค่าเท่ากับค่าที่เลือก ส่งแบบ get ไปที่ไฟล์ data_for_list2.php

               $.get("Mode/selectSchool.php",{
                district:$(this).val()
               },function(data){ // คืนค่ากลับมา
                 //alert("yyyy");
                $("select#school").html(data);  // นำค่าที่ได้ไปใส่ใน select id เท่ากับ list2
              });
             });     
          
        });
      </script> 
    </body>
    </html>