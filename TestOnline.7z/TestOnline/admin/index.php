<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>หน้าหลัก</title>
  <style type="text/css">
    .imghead{}

    img{
      width: 250px;
      height: 250px;
      margin-top: 2px;
      text-align: center;
      -moz-box-shadow: 5px 5px 5px #fff;  
      -webkit-box-shadow: 5px 5px 5px #fff;  
      box-shadow: 5px 5px 5px #fff;

    }
    .b{
      color: #BDBDBD;
      margin-left: 0%;
      font-size: 12px;
    }

    .comment{
      margin-left: 20px;
    }
    .comment h4{
      margin-left: 10px;
      font-size: 11px;
      color: #424242;

    }
    .imga{
      text-align: center;
      width: 180px;
      height: 100px;
      margin-left: 5%;
    }
    .scrollbar10{
      width:100%;
      height:400px;
      overflow-y:scroll;


    }
    #ex10::-webkit-scrollbar{
      width:10px;


    } 
    #ex10::-webkit-scrollbar-thumb{

      border-radius:10px;
    }
    #ex10::-webkit-scrollbar-thumb:hover{
      background-color:#90CAF9;
      border:10px solid #90CAF9;

    }
    #ex10::-webkit-scrollbar-thumb:active{
      background-color:#BBDEFB;
      border:10px solid #BBDEFB;

    } 
    #ex10::-webkit-scrollbar-track{
      border:2px ;
      border-radius:10px;

    </style>

  </head>
  <body>
   <div id="wrapper">

    <?php
    $date = date("Y-m-d");
    function DateThai($strDate)
    {
      $strYear = date("Y",strtotime($strDate))+543;
      $strMonth= date("n",strtotime($strDate));
      $strDay= date("j",strtotime($strDate));
      $strHour= date("H",strtotime($strDate));
      $strMinute= date("i",strtotime($strDate));
      $strSeconds= date("s",strtotime($strDate));
      $strMonthCut = Array("","ม.ค.","ก.พ.","มี.ค.","เม.ย.","พ.ค.","มิ.ย.","ก.ค.","ส.ค.","ก.ย.","ต.ค.","พ.ย.","ธ.ค.");
      $strMonthThai=$strMonthCut[$strMonth];
      return "$strDay $strMonthThai $strYear";
    }

    function DateThai1($strDate)
    {
      $strYear = date("Y",strtotime($strDate))+543;
      $strMonth= date("n",strtotime($strDate));
      $strDay= date("j",strtotime($strDate));
      $strHour= date("H",strtotime($strDate));
      $strMinute= date("i",strtotime($strDate));
      $strSeconds= date("s",strtotime($strDate));
      $strMonthCut = Array("","ม.ค.","ก.พ.","มี.ค.","เม.ย.","พ.ค.","มิ.ย.","ก.ค.","ส.ค.","ก.ย.","ต.ค.","พ.ย.","ธ.ค.");
      $strMonthThai=$strMonthCut[$strMonth];
      return "$strDay $strMonthThai $strYear, $strHour:$strMinute";
    }

    require_once("mysqlconnect.php");
    include('manu.php');
    ?>
    <div id="page-wrapper">
     <div class="container-fluid">
      <div class="row">
        <div class="col-lg-12">
          <h1 class="page-header">
            ชุดข้อสอบ
          </h1>
          
        </div>
      </div>
      <div class="row">
        <div class="col-lg-12">
          <form class="form-horizontal" action="" id="myform1" name="frmMain" method="post"  >
            <div class="input-group">
              <input type="text" name="txtex_id" class="form-control" placeholder="ระบุรหัสชุดข้อสอบ...">
              <span class="input-group-btn">
                <button type="submis" class="btn btn-default" name="sechiud" type="button">ค้นหา!</button>
              </span>
            </div>
          </form>
        </div>
      </div>
      <?php
      $IDUsers =$_SESSION['u_id'];
      ?>

      <div class="row">
       <div class="list-group">
        <?php 
        if(isset($_POST['sechiud'])){
          $ex_id = $_POST['txtex_id'];
          $sql_dl=" SELECT eh.ex_id,eh.ex_name,eh.ex_detail,eh.ex_course,eh.ex_date,eh.ex_numberExams,eh.ex_idProfessor,eh.ex_OpenExam,eh.ex_CloseExam,u.u_firstName,u.u_lastName FROM examination_header eh ,users u WHERE eh.ex_idProfessor = u.u_id  AND eh.ex_id LIKE '$ex_id%'
          order by eh.ex_date asc ";
        }else{
          $sql_dl=" SELECT eh.ex_id,eh.ex_name,eh.ex_detail,eh.ex_course,eh.ex_date,eh.ex_numberExams,eh.ex_idProfessor,eh.ex_OpenExam,eh.ex_CloseExam,u.u_firstName,u.u_lastName FROM examination_header eh ,users u WHERE eh.ex_idProfessor = u.u_id order by eh.ex_date asc";
        }
        $result_dl = $dbc->query($sql_dl);
        $l=1;
        if ($result_dl->num_rows > 0) {
          while($row_dl = $result_dl->fetch_assoc()){
            ?>
            <br>
            <a class="list-group-item list-group-item-success" href="#" >
              <h4 class="list-group-item-heading"><?php echo $l++ .". " .$row_dl["ex_name"]; ?></h4>
              <p  class="list-group-item-text"><?php echo "<b>รายละเอียด</b> ".$row_dl["ex_detail"]; ?></p>
              <p  class="list-group-item-text"><?php echo "<b>รายวิชา </b> ".$row_dl["ex_course"] ."  <b>ผู้สอน </b> ".$row_dl["u_firstName"]." ".$row_dl["u_lastName"]; ?></p>
              <p  class="list-group-item-text"><?php echo "<b>รหัสชุดข้อสอบ </b> ".$row_dl["ex_id"] ."  <b>จำนวนข้อสอบ </b> ".$row_dl["ex_numberExams"] ." ข้อ". "  <b>นักเรียนชั้น</b> ป.6"; ?></p>
              <p  class="list-group-item-text"><?php echo "<b>วันที่จัดทำชุดข้อสอบ </b> ".DateThai($row_dl["ex_date"])."  
              <b>วันที่เปิดสอบ</b>".DateThai1($row_dl["ex_OpenExam"])."  <b>วันที่ปิดสอบ</b>".DateThai1($row_dl["ex_CloseExam"]) ; ?></p>
              <br>
            </a>
            <?php
          }
        }else{
          echo("<h3 class='page-header'> ไม่พบชุดข้อสอบ </h3>");
        }
        ?>
      </div>
    </div>

  </div>
</div>
</div>
</body>
</html>