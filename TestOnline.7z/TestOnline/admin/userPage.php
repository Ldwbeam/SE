
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>หน้าหลัก</title>
  <style type="text/css">
    .imghead{}
  

    img{
      width: 250px;
      height: 250px;
      margin-top: 2px;
      text-align: center;
      -moz-box-shadow: 5px 5px 5px #fff;  
      -webkit-box-shadow: 5px 5px 5px #fff;  
      box-shadow: 5px 5px 5px #fff;

    }
    .b{
      color: #BDBDBD;
      margin-left: 0%;
      font-size: 12px;
    }

    .comment{
      margin-left: 20px;
    }
    .comment h4{
      margin-left: 10px;
      font-size: 11px;
      color: #424242;

 
   .imga{
    text-align: center;
    width: 180px;
    height: 100px;
    margin-left: 5%;
  }
  .scrollbar10{
    width:100%;
    height:400px;
    overflow-y:scroll;


  }
  #ex10::-webkit-scrollbar{
    width:10px;


  } 
  #ex10::-webkit-scrollbar-thumb{

    border-radius:10px;
  }
  #ex10::-webkit-scrollbar-thumb:hover{
    background-color:#90CAF9;
    border:10px solid #90CAF9;

  }
  #ex10::-webkit-scrollbar-thumb:active{
    background-color:#BBDEFB;
    border:10px solid #BBDEFB;

  } 
  #ex10::-webkit-scrollbar-track{
    border:2px ;
    border-radius:10px;

  </style>

</head>
<body>

  <?php
  $date = date("Y-m-d");
  function getNumDay($d1,$d2){
    $dArr1    = preg_split("/-/", $d1);
    list($year1, $month1, $day1) = $dArr1;
    $Day1 =  mktime(0,0,0,$month1,$day1,$year1);

    $dArr2    = preg_split("/-/", $d2);
    list($year2, $month2, $day2) = $dArr2;
    $Day2 =  mktime(0,0,0,$month2,$day2,$year2);

    return round(abs( $Day2 - $Day1 ) / 86400 )+1;
  }

  ?>
  <div id="wrapper">
   <?php
   require_once("mysqlconnect.php");
   include('manu.php');
   ?>
   <div id="page-wrapper">
     <div class="container-fluid">
      <div class="row">
        <div class="col-lg-12">
          <h1 class="page-header">
            รายชื่อผู้ใช้งาน
          </h1>
          <ol class="breadcrumb">
            <li>
              <i class="fa fa-dashboard"></i>  <a href="index.php">ระบบสอบออนไลน์</a>
            </li>
            <li class="active">
              <i class="glyphicon glyphicon-th"></i> รายชื่อผู้ใช้งาน
            </li>

            <li>
              <i class="
              glyphicon glyphicon-plus-sign"></i>  <a href='inserUser.php'>เพิ่มผู้ดูแลระบบ</a>
            </li>
          </ol>
        </div>
      </div>
      <div class="row">
        <div class="col-lg-12 a" >
          <form class="form-inline" action="userPage.php" method="get">
            <div class="form-group">
              <h4 class="form-control-static">ชื่อผู้ใช้งาน</h4>
              <input type="text" class="form-control" placeholder="Search" name="SearchName">
              <button type="submit" class="btn btn-default" name="Search"><i class="glyphicon glyphicon-search
                "></i></button>
              </div>

            </form>
          </div>
        </div>
        <div class="row">
          <br>
          <div class="col-lg-12 scrollbar table-responsive" id="ex3">
            <table class="table table table-bordered table-hover " >
              <thead>
                <tr>
                  <th>#</th>
                  <th>ชื่อ/นามสกุล</th>
                  <th>ที่อยู่</th>
                  <th>Email</th>
                  <th>เบอร์โทร</th>
                  <th>สถานะเข้าใช้งาน</th>
                  <th></th>

                </tr>
              </thead>
              <tbody class="">
                <?php
                if(!isset($_GET['Search'])){
                  $sql=" SELECT U.u_id,U.u_firstName,U.u_lastName,U.u_address,U.IDCanton,U.IDDistrict,U.IDProvince,U.u_email,U.u_tell,U.u_schoolID,U.u_type,D.NameDistrict,C.NameCanton,P.ProvinceName FROM users U, district D ,canton C, province P where U.IDCanton = C.IDCanton AND U.IDDistrict = D.IDDistrict AND U.IDProvince = P.IDProvince   ORDER BY U.u_firstName ASC";
                  $result = $dbc->query($sql);
                  $l=1;
                  if ($result->num_rows > 0) {
                    while($row = $result->fetch_assoc()) {
                      ?>
                      <tr>
                        <td><?php echo $l++; ?></td>
                        <td><?php echo $row['u_firstName']." ". $row['u_lastName'];?></td>

                        <td><?php echo $row['u_address']." ต.".$row['NameCanton']." อ.".$row['NameDistrict']." จ.".$row['ProvinceName'];?></td>
                        <td><?php echo $row["u_email"];?></td>
                        <td><?php echo $row["u_tell"];?></td>
                        <td><?php 
                        if( $row["u_type"]=="2"){
                          echo "ผู้ดูแล";
                        }else if($row['u_type']=="1"){
                          echo "อาจารย์";
                        }else{
                         echo "นักเรียน";
                       }
                       ?>
                     </td>
                     <td>
                      <div >
                        <form  method="get" action = "" onkeypress="return event.keyCode != 13;" >
                        <a href="inserUser.php?u_id=<?=$row['u_id'];?>" class="btn btn-success"> <i class="glyphicon glyphicon-edit"></i> แก้ไข</a>
                             <input type="hidden" id="idUser" name="idUser" value="<?=$row['u_id'];?>">
                        <button type="submit" class="btn btn-info" name="bntDUser"><i class="glyphicon glyphicon-remove-circle"></i> ลบ</button>
                      </form>
                      </div>
                    </td>
                  </tr>
                  <?php

                }
              }
            }

            if(isset($_GET['Search'])){
              $u_name = $_GET['SearchName'];
              $sql=" SELECT U.u_id,U.u_firstName,U.u_lastName,U.u_address,U.IDCanton,U.IDDistrict,U.IDProvince,U.u_email,U.u_tell,U.u_schoolID,U.u_type,D.NameDistrict,C.NameCanton,P.ProvinceName FROM users U, district D ,canton C, province P where U.IDCanton = C.IDCanton AND U.IDDistrict = D.IDDistrict AND U.IDProvince = P.IDProvince  AND u_firstName LIKE '$u_name%'  ORDER BY U.u_firstName ASC ";
              $result = $dbc->query($sql);
              $l=1;
              if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                   ?>
                      <tr>
                        <td><?php echo $l++; ?></td>
                        <td><?php echo $row['u_firstName']." ". $row['u_lastName'];?></td>

                        <td><?php echo $row['u_address']." ต.".$row['NameCanton']." อ.".$row['NameDistrict']." จ.".$row['ProvinceName'];?></td>
                        <td><?php echo $row["u_email"];?></td>
                        <td><?php echo $row["u_tell"];?></td>
                        <td><?php 
                        if( $row["u_type"]=="2"){
                          echo "ผู้ดูแล";
                        }else if($row['u_type']=="1"){
                          echo "อาจารย์";
                        }else{
                         echo "นักเรียน";
                       }
                       ?>
                     </td>
                     <td>
                      <div >
                        <form  method="get" action = "" onkeypress="return event.keyCode != 13;" >
                        <a href="editStudent.php?id=<?=$row['id'];?>" class="btn btn-success"> <i class="glyphicon glyphicon-edit"></i> แก้ไข</a>
                             <input type="hidden" id="idUser" name="idUser" value="<?=$row['u_id'];?>">
                        <button type="submit" class="btn btn-info" name="bntDUser"><i class="glyphicon glyphicon-remove-circle"></i> ลบ</button>
                      </form>
                      </div>
                    </td>
                  </tr>
              <?php

            }
          }
        }

        ?>
      </tbody>
    </table>
  </div>
</div>
</div>
<?php
   if(isset($_GET['bntDUser'])){
        $idUser = $_GET['idUser'];
        $delete = $dbc->prepare("DELETE FROM users WHERE u_id = ?");
        $delete->bind_param("s",$idUser);
        $delete->execute();
        ?>
        <div class="container">
          <div class="modal show" id="myModal" role="dialog">
            <div class="modal-dialog">

              <!-- Modal content-->
              <div class="modal-content">
                <div class="modal-header">
                  <a href="userPage.php" type="button" class="close"  onclick = "$('.modal').removeClass('show').addClass('fade');" data-dismiss="modal">&times;</a>
                  <h4 class="modal-title">ลบสำเร็จ</h4>
                </div>
                <div class="modal-body">
                  <p>สามารถลบข้อมูลสำเร็จ.</p>
                </div>
                <div class="modal-footer">
                  <a type="button" href="userPage.php"  class="btn btn-default" onclick = "$('.modal').removeClass('show').addClass('fade');" data-dismiss="modal">Close</a>
                </div>
              </div>

            </div>
          </div>
        </div>
        <?php
      }
      ?>

<script src="../js/jquery.js"></script>
<script src="../js/checkforms.js"></script>
<script src="../js/inputdate.js"></script>
<script src="../js/jquery.datetimepicker.js"></script>
<script src="../build/jquery.datetimepicker.full.js"></script>

</body>
</html>