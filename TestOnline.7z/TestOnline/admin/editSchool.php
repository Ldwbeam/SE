
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>หน้าหลัก</title>
  <style type="text/css">
    .imghead{}

    img{
      width: 250px;
      height: 250px;
      margin-top: 2px;
      text-align: center;
      -moz-box-shadow: 5px 5px 5px #fff;  
      -webkit-box-shadow: 5px 5px 5px #fff;  
      box-shadow: 5px 5px 5px #fff;

    }
    .b{
      color: #BDBDBD;
      margin-left: 0%;
      font-size: 12px;
    }

    .comment{
      margin-left: 20px;
    }
    .comment h4{
      margin-left: 10px;
      font-size: 11px;
      color: #424242;

    }
    .imga{
      text-align: center;
      width: 180px;
      height: 100px;
      margin-left: 5%;
    }
    .scrollbar10{
      width:100%;
      height:400px;
      overflow-y:scroll;


    }
    #ex10::-webkit-scrollbar{
      width:10px;


    } 
    #ex10::-webkit-scrollbar-thumb{

      border-radius:10px;
    }
    #ex10::-webkit-scrollbar-thumb:hover{
      background-color:#90CAF9;
      border:10px solid #90CAF9;

    }
    #ex10::-webkit-scrollbar-thumb:active{
      background-color:#BBDEFB;
      border:10px solid #BBDEFB;

    } 
    #ex10::-webkit-scrollbar-track{
      border:2px ;
      border-radius:10px;

    </style>

  </head>
  <body>

    <?php
    $date = date("Y-m-d");
    function getNumDay($d1,$d2){
      $dArr1    = preg_split("/-/", $d1);
      list($year1, $month1, $day1) = $dArr1;
      $Day1 =  mktime(0,0,0,$month1,$day1,$year1);

      $dArr2    = preg_split("/-/", $d2);
      list($year2, $month2, $day2) = $dArr2;
      $Day2 =  mktime(0,0,0,$month2,$day2,$year2);

      return round(abs( $Day2 - $Day1 ) / 86400 )+1;
    }

    ?>
    <div id="wrapper">
     <?php
     $NameSchool ="";
     $IDDistrict = "";
     $NameDistrict ="";
     $IDProvince = "";
     $ProvinceName="";
     require_once("mysqlconnect.php");
     include('manu.php');
     $id_school=$_REQUEST["IDSchool"];
     $scl="SELECT S.IDSchool,S.NameSchool,S.IDDistrict,D.NameDistrict,D.IDProvince,P.ProvinceName FROM school S, district D, province P WHERE S.IDDistrict =D.IDDistrict AND D.IDProvince = P.IDProvince AND S.IDSchool = '$id_school'";
     $resultscl = $dbc->query($scl);
     if ($resultscl->num_rows > 0) {
      while($rowscl = $resultscl->fetch_assoc()) {
        $NameSchool = $rowscl['NameSchool'];
        $IDDistrict = $rowscl['IDDistrict'];
        $NameDistrict =$rowscl['NameDistrict'];
        $IDProvince = $rowscl['IDProvince'];
        $ProvinceName = $rowscl['ProvinceName'];
      }
    }
    ?>
    <div id="page-wrapper">
     <div class="container-fluid">
      <!-- Page Heading -->
      <div class="row">

        <div class="col-lg-12">
          <h1 class="page-header">
            แก้ไขรายชื่อโรงเรียน
          </h1>
          <ol class="breadcrumb">
            <li>
              <i class="fa fa-dashboard"></i>  <a href="index.php">ระบบสอบออนไลน์</a>
            </li>
            <li class="active">
              <i class="glyphicon glyphicon-th"></i> แก้ไขรายชื่อโรงเรียน
            </li>

          </ol>
        </div>
      </div>

      <div class="row">
        <br>
        <form  method="post" action = "" onkeypress="return event.keyCode != 13;" id="myform1"enctype="multipart/form-data" >
          <div class="form-group ">
            <label for="exampleInputEmail2">ชื่อโรงเรียน</label>
            <input type="text" class="form-control css-require" id="exampleInputEmail2" placeholder="ชื่อโรงเรียน" name="txtNameSchool" value="<?php echo $NameSchool; ?>">
          </div>

          <div class="form-group">
            <label for="exampleInputEmail2">จังหวัด</label>
            <select class="form-control css-require" name="Rovince" id="Rovince">
              <option value="">เลือก</option>
              <?php
              $sql=" SELECT IDProvince,ProvinceName FROM province";
              $result = $dbc->query($sql);
              if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                  if($row['IDProvince'] ==$IDProvince){
                    ?>
                    <option value="<?php echo $row['IDProvince'];?>" selected><?php echo $row['ProvinceName'];?>
                  </option>
                  <?php
                }else{
                  ?>
                  <option value="<?php echo $row['IDProvince'];?>"><?php echo $row['ProvinceName'];?>
                </option>
                <?php
              }
            }
          }
          ?>
        </select> 
      </div>
      <div class="form-group">
        <label for="exampleInputEmail2">อำเภอ</label>
        <select class="form-control css-require" name="district" id="district">
          <option value="<?php echo $IDDistrict; ?>"><?php echo $NameDistrict; ?></option>
        </select>

      </div>

      <div class="modal-footer">
        <a href="schoolPage.php" type="button" class="btn btn-default" data-dismiss="modal">ยกเลิก</a>
        <button type="submit" class="btn btn-primary" name="bntUpSchool">ยืนยัน</button>
      </div>
    </form>

  </div>
</div>
</div>


<?php
if(isset($_POST['bntUpSchool'])){
  $schoolName = $_POST['txtNameSchool'];
  $District = $_POST['district'];
  $stmt = $dbc->prepare("UPDATE school SET NameSchool =? , IDDistrict = ? WHERE IDSchool = $id_school");
  $stmt->bind_param("ss",$schoolName,$District);
  $stmt->execute();
  ?>
  <div class="container">
    <div class="modal show" id="myModal" role="dialog">
      <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
          <div class="modal-header">
            <a href="schoolPage.php" type="button" class="close"  onclick = "$('.modal').removeClass('show').addClass('fade');" data-dismiss="modal">&times;</a>
            <h4 class="modal-title">สำเร็จ</h4>
          </div>
          <div class="modal-body">
            <p>สามารถแก้ไขข้อมูล <?php echo $schoolName ; ?>  สำเร็จ.</p>
          </div>
          <div class="modal-footer">
            <a type="button" href="schoolPage.php"  class="btn btn-default" onclick = "$('.modal').removeClass('show').addClass('fade');" data-dismiss="modal">Close</a>
          </div>
        </div>

      </div>
    </div>
  </div>
  <?php

}
?>
<script src="../js/jquery.js"></script>
<script src="../js/checkforms.js"></script>
<script src="../js/inputdate.js"></script>
<script src="../js/jquery.datetimepicker.js"></script>
<script src="../build/jquery.datetimepicker.full.js"></script>
<script type="text/javascript">
  $(function(){
          // เมื่อเปลี่ยนค่าของ select id เท่ากับ list1
          $("select#Rovince").change(function(){  

               // ส่งค่า ตัวแปร list1 มีค่าเท่ากับค่าที่เลือก ส่งแบบ get ไปที่ไฟล์ data_for_list2.php

               $.get("Mode/selectDistrict.php",{
                Rovince:$(this).val()
               },function(data){ // คืนค่ากลับมา
                 //alert("yyyy");
                $("select#district").html(data);  // นำค่าที่ได้ไปใส่ใน select id เท่ากับ list2
              });
             });     
          
        });
      </script> 
      <script type="text/javascript">
        $(window).on('load',function(){
          $('#inschool').modal('show');
        });
      </script>

    </body>
    </html>