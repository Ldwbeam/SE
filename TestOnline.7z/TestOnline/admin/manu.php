<?php
//error_reporting( error_reporting() & ~E_NOTICE );
session_start();
if($_SESSION['u_id']==""){
	 header("location:http://localhost:44333/TestOnline/login.php");
}
//include('input.php');
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="shortcut icon" href="../img/DRU.jpg" type="image/x-icon">
	<title>ระบบข้อสอบออนไลน์</title>
	<link href="../css/bootstrap.min.css" rel="stylesheet">
	<link href="../css/sb-admin.css" rel="stylesheet">
	<link href="../css/plugins/morris.css" rel="stylesheet">
	<link href="../font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
	<link href="../loading/jquery.pageLoading.css" rel="stylesheet">
	<style type="text/css">
		.coct{

		}
		.coct h6{
			font-size: 12px;
			margin-top: -120px;

		}
	</style>
</head>
<body style="background: #ffff;">
	
	<!-- Navigation -->
	<nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
		<div class="navbar-header">
			<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
				<span class="sr-only">ผู้ดูแลระบบ</span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			</button>
			<a class="navbar-brand" href="index.php"> ระบบจัดทำข้อสอบออนไลน์</a>
		</div>
		<!-- Top Menu Items -->
		<ul class="nav navbar-right top-nav">

           <li class="dropdown">
				<a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user"></i> <?php 
					if($_SESSION['userType'] == '2'){
                      echo "สิทธ์การใช้งานเป็น admin ";
					}else{
						 echo "สิทธ์การใช้งานเป็น อาจารย์ ";
					}
				 ?> <b class="caret"></b></a>
			</li>
			<li class="dropdown">
				<a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user"></i> <?php echo $_SESSION['nameAdmin']; ?> <b class="caret"></b></a>
				<ul class="dropdown-menu">
					<li>
						<a href="mode/logout.php"><i class="fa fa-fw fa-power-off"></i> ออกจากระบบ</a>
					</li>
				</ul>
			</li>
		</ul>
		<!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
		<div class="collapse navbar-collapse navbar-ex1-collapse">
			<ul class="nav navbar-nav side-nav">
				<li class="">
					<a href="index.php"><i class="glyphicon glyphicon-home"></i> หน้าหลัก</a>
				</li>
				<li>
					<a href="userPage.php"><i class="glyphicon glyphicon-user"></i> ข้อมูลผู้ใช้งาน</a>
				</li>
				<li>
					<a href="schoolPage.php"><i class="glyphicon glyphicon-queen"></i> ข้อมูลโรงเรียน</a>
				</li>
				</ul>
			</div>
		</nav>

		<script src="../js/jquery.js"></script>

		<!-- Bootstrap Core JavaScript -->
		<script src="../js/bootstrap.min.js"></script>

		<!-- Morris Charts JavaScript -->
		<script src="../js/plugins/morris/raphael.min.js"></script>
		<script src="../js/plugins/morris/morris.min.js"></script>
		<script src="../js/plugins/morris/morris-data.js"></script>
		<script src="../loading/jquery.pageLoading.js"></script>
	
</body>
</html>