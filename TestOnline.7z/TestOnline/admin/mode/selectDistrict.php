
<?php
require_once("../mysqlconnect.php");
header("Content-type:text/html; charset=UTF-8");              
header("Cache-Control: no-store, no-cache, must-revalidate");             
header("Cache-Control: post-check=0, pre-check=0", false);   
?>
<?php if(isset($_GET['Rovince']) && $_GET['Rovince']!=""){?>
<option value="">เลือกรายการ</option>
<?php
  $ggg=$_GET['Rovince'];

  $sql=" SELECT * FROM district WHERE IDProvince = $ggg";
  $result = $dbc->query($sql);
 if ($result->num_rows > 0) {
      while($row = $result->fetch_assoc()) {
     ?>
          
         <option value="<?php echo $row['IDDistrict'];?>"><?php echo $row['NameDistrict'];?></option>
                                              
    <?php

        }
    }
                                           ?>
                                         
<?php }else{ ?>
  <option value="">เลือกรายการ</option>
<?php } ?>




 