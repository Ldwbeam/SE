
<?php
session_start();
require_once("../mysqlconnect.php");
	  session_destroy(); // ล้างค่าตัวแปรทั้งหมดออกให้เกลี้ยงเลย....
	  //$_SESSION["id"]=""; // ล้างตัวแปร user ให้เป็นค่าว่าง ที่จริงแค่บรรทัดข้างบนก็ล้างออกหมดแล้ว แต่กลัวตัวเองไม่เข้าใจก็เลย...และสุดท้ายก็แจ้งให้เขาทราบว่า คุณได้ล๊อกเอ้าออกจากระบบเรียบร้อยแล้ว
      header("location:http://localhost:44333/TestOnline/login.php");

?>