<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<link rel="shortcut icon" href="../img/DRU.jpg" type="image/x-icon">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>login</title>
  <link rel="stylesheet" href="../css/bootstrap.min.css" type="text/css">
  <link rel="stylesheet" href="../font-awesome/css/font-awesome.min.css" type="text/css">
  <link rel="stylesheet" href="../css/creative.css" type="text/css">
  <link rel="stylesheet" type="text/css" href="../css/normalize.css" />
  <script src="../js/jquery.js"></script>
  <script src="../js/bootstrap.min.js"></script>
  <script>
    $(document).ready(function(){
    // Show the Modal on load
    $("#myModal").modal("show");
    
    // Hide the Modal
    $("#myBtn").click(function(){
      $("#myModal").modal("hide");
    });
  });
</script>
<style>
  #myBtn {
    width: 300px;
    padding: 10px;
    font-size:20px;
    position: absolute;
    margin: 0 auto;
    right: 0;
    left: 0;
    bottom: 50px;
    z-index: 9999;
  }
</style>

<?php
session_start();
require_once("../mysqlconnect.php");
$username=$_POST['txtUserName'];
$password=$_POST['txtPassWord'];
$_SESSION['u_id']= "";
$_SESSION['nameAdmin']= "";
$_SESSION['userType']= "";
$view_A="";
$id_A="";

$sql=" SELECT * FROM users WHERE u_userName = '$username' AND   u_password = '$password' AND  u_type IN(2)";
$result = $dbc->query($sql);
if ($result->num_rows > 0) {
  while($row = $result->fetch_assoc()){
  //  $view_A = $row['viewloin']+1;
  //  $id_A=$row["id"];

    $_SESSION['u_id'] =$row["u_id"];
//    $_SESSION['admin_status'] =$row["admin_status"];
    $_SESSION['nameAdmin']= $row["u_firstName"] ." ". $row["u_lastName"];
    $_SESSION['userType'] = $row['u_type'];

   

    header("location:../index.php");
  }
}
else
{
  	//header("location:index.php");
  	//echo "<script>alert('ไม่สามารถเข้าระบบได้!!!! กรุณาตรวจสอบ')</script>";
  	//location = 'http://www.thaiwebcreator.com';

 /*echo "<script>
 if(confirm('ไม่สามารถเข้าระบบได้!!!! กรุณาตรวจสอบ username password อีกครั้ง'))
 {

  header('location:system.php');
}
else
{
  history.back();
}
</script>";*/
?>
<a href="javascript:history.back()">
  <div class="container">
    <!-- Modal -->
    <div class="modal fade" id="myModal" role="dialog">
      <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
          <div class="modal-header">
            <h4 class="modal-title"><i class="glyphicon glyphicon-info-sign " style="color:#D50000;"> เกิดข้อผิดพลาด</i></h4>
          </div>
          <div class="modal-body">
           
          </div>
        </div>

      </div>
    </div>
  </div>
</a>
<?php
}
?>
</body>
</html>