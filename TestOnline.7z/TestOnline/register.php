
<?php
require_once("mysqlconnect.php");
?>
<!DOCTYPE html>
<html lang="en">

<head>

	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="shortcut icon" href="img/shop.jpg" type="image/x-icon">
	<meta name="description" content="">
	<meta name="author" content="">
	<title>สมัครสมาชิก</title>
	<link href="css/bootstrap.min.css" rel="stylesheet">

</head>
<body>
	<div id="page-wrapper">
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<h1 class="page-header">
						สมัครสมาชิก
					</h1>
					
				</div>
			</div>
			<form class="form-horizontal" action="" id="myform1" name="frmMain" method="post" onkeypress="return event.keyCode != 13;" onsubmit="return validateForm()">

				<div class="row">
					<div class="col-sm-12 ">
						<label for="inputEmail3" class="col-sm-2 control-label">ชื่อ<t style="color: #ff0000;">*</t></label>
						<div class="col-sm-4 form-group ">
							<input type="text" class="form-control css-require" id="exampleInputEmail2" placeholder="นาย/นางสาว" name="txtfirstName">
						</div>
						<label for="inputEmail3" class="col-sm-1 control-label">นามสกุล<t style="color: #ff0000;">*</t></label>
						<div class="col-sm-4 form-group " >
							<input type="text" class="form-control css-require " id="exampleInputEmail2" placeholder="นามสกุล" name="txtlastName">
						</div>
					</div>
				</div>

				<div class="row ">
					<div class="col-sm-12 ">
						<label for="inputEmail3" class="col-sm-2 control-label">UserName<t style="color: #ff0000;">*</t></label>
						<div class="col-sm-4 form-group">
							<input type="text" class="form-control css-require" id="exampleInputEmail2" placeholder="UserName" name="txtUserName">
						</div>
						<label for="inputEmail3" class="col-sm-1 control-label">Password<t style="color: #ff0000;">*</t></label>
						<div class="col-sm-4 form-group">
							<input type="password" class="form-control css-require" id="exampleInputEmail2" placeholder="****" name="txtPassword">
						</div>
					</div>
				</div>

				<div class="row">
					<div class="col-sm-12 ">
						<label for="inputEmail3" class="col-sm-2 control-label">ที่อยู่<t style="color: #ff0000;">*</t></label>
						<div class="col-sm-8 form-group">
							<input type="text" class="form-control css-require" id="exampleInputEmail2" placeholder="บ้านเลขที่.. หมู่ที่.. หมู่บ้าน.. " name="txtAddess">
						</div>
					</div>
				</div>

				<div class="row">
					<div class="col-sm-12 ">
						<label for="inputEmail3" class="col-sm-2 control-label">จังหวัด<t style="color: #ff0000;">*</t></label>
						<div class="col-sm-2 form-group">
							<select class="form-control css-require" name="Rovince" id="Rovince">
								<option value="">เลือกรายการ</option>
								<?php
								$sql=" SELECT IDProvince,ProvinceName FROM province  ORDER BY ProvinceName ASC ";
								$result = $dbc->query($sql);
								if ($result->num_rows > 0) {
									while($row = $result->fetch_assoc()) {?>
										<option value="<?php echo $row['IDProvince'];?>"><?php echo $row['ProvinceName'];?>
									</option>
									<?php
								}
							}
							?>
						</select> 
					</div>
					<label for="inputEmail3" class="col-sm-1 control-label">อำเภอ<t style="color: #ff0000;">*</t></label>
					<div class="col-sm-2 form-group">
						<select class="form-control css-require" name="district" id="district">
							<option value="">เลือกรายการ</option>
						</select>
					</div>
					<label for="inputEmail3" class="col-sm-1 control-label">ตำบล<t style="color: #ff0000;">*</t></label>
					<div class="col-sm-2 form-group">
						<select class="form-control css-require" name="canton" id="canton">
							<option value="">เลือกรายการ</option>
						</select>
					</div>
				</div>
			</div>
			
			
			<div class="row">
				<div class="col-sm-12 ">
					<label for="inputEmail3" class="col-sm-2 control-label">สังกัดโรงเรียน<t style="color: #ff0000;">*</t></label>
					<div class="col-sm-4 form-group">
						<select class="form-control css-require" name="school" id="school">
							<option value="">เลือกรายการ </option>
						</select> 
					</div>
				</div>
			</div>

			<div class="row">
				<div class="col-sm-12 ">
					<label for="inputEmail3" class="col-sm-2 control-label">Email<t style="color: #ff0000;">*</t></label>
					<div class="col-sm-3 form-group">
						<input type="Email" class="form-control css-require" id="exampleInputEmail2" placeholder="Email" name="txtEmail">
					</div>
					<label for="inputEmail3" class="col-sm-2 control-label">เบอร์โทรศัพท์<t style="color: #ff0000;">*</t></label>
					<div class="col-sm-3 form-group">
						<input type="tel" pattern="[0-9]{10}" required class="form-control css-require "
						id="exampleInputEmail2" placeholder="เบอร์โทร" name="txtphone">

					</div>
				</div>
			</div>

			<div class="form-group">
				<div class="col-sm-12 ">
					<label for="inputEmail3" class="col-sm-2 control-label">สิทธ์เข้าใช้งาน<t style="color: #ff0000;">*</t></label>
					<div class="col-sm-4 form-group">
						<select class="form-control css-require" name="utype" id="utype" onchange="showStudent();">
							<option value="">เลือกรายการ </option>
							<option value="0" selected>นักเรียน </option>
							<option value="1" >อาจารย์ </option>
						</select> 
					</div>
				</div>
			</div>

			<div class="row" id="student">
				<div class="col-sm-12 ">
					<label for="inputEmail3" class="col-sm-2 control-label">รหัสนักเรียน<t style="color: #ff0000;">*</t></label>
					<div class="col-sm-3 form-group">
						<input type="number"  id="studentCode" class="form-control" placeholder="รหัสนักเรียน" name="txtstudentCode">
					</div>
					<label for="inputEmail3" class="col-sm-2 control-label">ชั้นเรียน<t style="color: #ff0000;">*</t></label>
					<div class="col-sm-3 form-group">
						<select class="form-control" name="opClass" id="opClass">
							<option value="">เลือกรายการ </option>
							<option value="ม.1" >ม.1 </option>
							<option value="ม.2" >ม.2 </option>
							<option value="ม.3" >ม.3 </option>
							<option value="ม.4" >ม.4 </option>
							<option value="ม.5" >ม.5 </option>
							<option value="ม.6" >ม.6 </option>
						</select> 

					</div>
				</div>
			</div>
			<div class="modal-footer">
				<button type="button" onclick="window.history.back()" class="btn btn-default" data-dismiss="modal">ยกเลิก</button>
				<button type="submit" class="btn btn-primary" name="subInserUser">ยืนยัน</button>
			</div>
		</form>
	</div>




	<?php
//เพิ่มข้อมูล
	if(isset($_POST['subInserUser'])){
		$u_userName = $_POST['txtUserName'];
		$u_password = $_POST['txtPassword'];
		$u_firstName = $_POST['txtfirstName'];
		$u_lastName = $_POST['txtlastName'];
		$u_address = $_POST['txtAddess'];
		$IDCanton = $_POST['canton'];
		$IDDistrict = $_POST['district'];
		$IDProvince = $_POST['Rovince'];
		$u_email = $_POST['txtEmail'];
		$u_tell = $_POST['txtphone'];
		$u_schoolID = $_POST['school'];
		$u_type = $_POST['utype'];
		$u_studentCode = $_POST['txtstudentCode'];
		$u_class = $_POST['opClass'];
		$stmt = $dbc->prepare("INSERT INTO users (u_userName,u_password,u_firstName,u_lastName,u_address,IDCanton,IDDistrict,IDProvince,u_email,u_tell,u_schoolID,u_type,u_studentCode,u_class) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
		$stmt->bind_param("ssssssssssssss",$u_userName,$u_password,$u_firstName,$u_lastName,$u_address,$IDCanton,$IDDistrict,$IDProvince,$u_email,$u_tell,$u_schoolID,$u_type,$u_studentCode,$u_class);
		$stmt->execute();

		?>
		<div class="container">
			<div class="modal show" id="myModal" role="dialog">
				<div class="modal-dialog">

					<!-- Modal content-->
					<div class="modal-content">
						<div class="modal-header">
							<a href="login.php" type="button" class="close"  onclick = "$('.modal').removeClass('show').addClass('fade');" data-dismiss="modal">&times;</a>
							<h4 class="modal-title">สำเร็จ</h4>
						</div>
						<div class="modal-body">
							<p>บันทึกข้อมูลของ <?php echo($u_firstName." ". $u_lastName) ?>  สำเร็จ.</p>
						</div>
						<div class="modal-footer">
							<a type="button" href="login.php"  class="btn btn-default" onclick = "$('.modal').removeClass('show').addClass('fade');" data-dismiss="modal">Close</a>
						</div>
					</div>

				</div>
			</div>
		</div>
	<?php } ?>
	<!-- jQuery -->
	<script src="js/jquery.js"></script>
	<script src="js/checkforms.js"></script>
	<script src="js/inputdate.js"></script>
	<script src="js/jquery.datetimepicker.js"></script>
	<script src="build/jquery.datetimepicker.full.js"></script>
	<script type="text/javascript">
		$(function(){
          // เมื่อเปลี่ยนค่าของ select id เท่ากับ list1
          $("select#Rovince").change(function(){  

               // ส่งค่า ตัวแปร list1 มีค่าเท่ากับค่าที่เลือก ส่งแบบ get ไปที่ไฟล์ data_for_list2.php

               $.get("admin/Mode/selectDistrict.php",{
               	Rovince:$(this).val()
               },function(data){ // คืนค่ากลับมา
                 //alert("yyyy");
                $("select#district").html(data);  // นำค่าที่ได้ไปใส่ใน select id เท่ากับ list2
            });
           });     
          
      });
  </script> 
  <script type="text/javascript">
  	$(function(){
          // เมื่อเปลี่ยนค่าของ select id เท่ากับ list1
          $("select#district").change(function(){  

               // ส่งค่า ตัวแปร list1 มีค่าเท่ากับค่าที่เลือก ส่งแบบ get ไปที่ไฟล์ data_for_list2.php

               $.get("admin/Mode/selectCanton.php",{
               	district:$(this).val()
               },function(data){ // คืนค่ากลับมา
                 //alert("yyyy");
                $("select#canton").html(data);  // นำค่าที่ได้ไปใส่ใน select id เท่ากับ list2
            });
           });     
          
      });
  </script> 
  <script type="text/javascript">
  	$(function(){
          // เมื่อเปลี่ยนค่าของ select id เท่ากับ list1
          $("select#district").change(function(){  

               // ส่งค่า ตัวแปร list1 มีค่าเท่ากับค่าที่เลือก ส่งแบบ get ไปที่ไฟล์ data_for_list2.php

               $.get("admin/Mode/selectSchool.php",{
               	district:$(this).val()
               },function(data){ // คืนค่ากลับมา
                 //alert("yyyy");
                $("select#school").html(data);  // นำค่าที่ได้ไปใส่ใน select id เท่ากับ list2
            });
           });     
          
      });
  </script> 
  <script >
  	function showStudent(){
  		var d=document.getElementById("utype");
  		var s = d.options[d.selectedIndex].value;

  		if(s=="0"){
  			document.getElementById('student').style.display = "";

  		}else{
  			document.getElementById('student').style.display = "none";
  		}

  	}
  </script>
  <script>
  	function validateForm() {
  		var x = document.forms["frmMain"]["txtstudentCode"].value;
  		var y = document.forms["frmMain"]["opClass"].value;
  		var d = document.forms["frmMain"]["utype"].value;
  		if(d == "0"){
  			if (x == "") {
  				alert("กรุณาระบุรหัสนักเรียน");
  				return false;
  			}
  			if(y==""){
  				alert("กรุณาเลือกชั้นเรียน");
  				return false;
  			}
  		}

  	}
  </script>
</body>
</html>