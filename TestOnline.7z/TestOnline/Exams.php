
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>กำลังทำข้อสอบ</title>
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <link href="css/plugins/morris.css" rel="stylesheet">
  <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

</head>
<body>

  <?php
  error_reporting( error_reporting() & ~E_NOTICE );
  session_start();
  $date = date("Y-m-d");
  function DateThai($strDate)
  {
    $strYear = date("Y",strtotime($strDate))+543;
    $strMonth= date("n",strtotime($strDate));
    $strDay= date("j",strtotime($strDate));
    $strHour= date("H",strtotime($strDate));
    $strMinute= date("i",strtotime($strDate));
    $strSeconds= date("s",strtotime($strDate));
    $strMonthCut = Array("","ม.ค.","ก.พ.","มี.ค.","เม.ย.","พ.ค.","มิ.ย.","ก.ค.","ส.ค.","ก.ย.","ต.ค.","พ.ย.","ธ.ค.");
    $strMonthThai=$strMonthCut[$strMonth];
    return "$strDay $strMonthThai $strYear";
  }

  ?>
  <div id="wrapper">
    <?php
    $ex_id = $_REQUEST["exId"];
    $ex_d_header_id ="";
    $ex_name ="";
    $ex_NameProfessor ="";
    $ex_course ="";
    $NameSchool ="";
    $ex_numberExams ="";
    require_once("mysqlconnect.php");

    $sql=" SELECT EH.ex_id,EH.ex_id,EH.ex_name,EH.ex_detail,EH.ex_course,EH.ex_numberExams,EH.ex_idProfessor,EH.ex_date,U.u_firstName,U.u_lastName ,S.NameSchool FROM examination_header EH, users U,school S WHERE EH.ex_idProfessor =U.u_id AND U.u_schoolID=s.IDSchool AND ex_id = '$ex_id'";
    $result = $dbc->query($sql);
    if ($result->num_rows > 0) {
      while($row = $result->fetch_assoc()){
        $ex_d_header_id = $row["ex_id"];
        $ex_name = $row["ex_name"];
        $ex_course= $row["ex_course"];
        $ex_NameProfessor = $row["u_firstName"] . " ".$row["u_lastName"];
        $NameSchool= $row["NameSchool"];
        $ex_numberExams =$row["ex_numberExams"];
      }
    }

    ?>

    <?php
    require_once("mysqlconnect.php");
  //include('manu.php');
    ?>
    <div id="page-wrapper">
     <div class="container-fluid">
      <div class="row">
        <div class="col-md-12 alert alert-info" role="alert">
          <p style="text-align: center; font-size: 35px;" >
           <?php
           echo("ชุดข้อสอบ ".$ex_name ." รหัส ".$ex_d_header_id." จำนวน ". $ex_numberExams ." ข้อ");

           ?>
         </p>
       </div>
     </div>
     <form class="form-horizontal" action="" id="myform1" name="frmMain" method="post" onkeypress="return event.keyCode != 13;" >
       <?php 
       $sql_dl=" SELECT ed.ex_d_id,ed.ex_d_header_id,ed.ex_d_title,es.ex_s_id,es.ex_s_A,es.ex_s_B,es.ex_s_C,es.ex_s_D,es.ex_s_cheap FROM examination_detail ed,examination_subitem es WHERE ed.ex_d_id = es.ex_s_d_id AND ed.ex_d_header_id = '$ex_id' ";
       $result_dl = $dbc->query($sql_dl);
       $l=1;
       if ($result_dl->num_rows > 0) {
        while($row_dl = $result_dl->fetch_assoc()){
         ?>
         <div class="row">
          <div class="col-xs-12 col-md-2"></div>
          <div class="col-xs-12 col-md-8">
            <h4><?php echo $l++ .". ".$row_dl["ex_d_title"]; ?> </h4>
            <input name="<?php echo "ex_d_id".($l-1); ?>" type="hidden" value=" <?php echo $row_dl["ex_d_id"]; ?>">
            <div class="radio">
              <label>
                <input type="radio" name="<?php echo "ro".($l-1);?>" id="optionsRadios1" value="A">
                <?php echo $row_dl["ex_s_A"]; ?>
              </label>
            </div>
            <div class="radio">
              <label>
                <input type="radio" name="<?php echo "ro".($l-1); ?>" id="optionsRadios2" value="B">
                <?php echo $row_dl["ex_s_B"]; ?>
              </label>
            </div>
            <div class="radio">
              <label>
                <input type="radio" name="<?php echo "ro".($l-1); ?>" id="optionsRadios3" value="C">
                <?php echo $row_dl["ex_s_C"]; ?>
              </label>
            </div>
            <div class="radio">
              <label>
                <input type="radio" name="<?php echo "ro".($l-1); ?>" id="optionsRadios4" value="D">
                <?php echo $row_dl["ex_s_D"]; ?>
              </label>
            </div>
            <input name="<?php echo "ex_s_cheap".($l-1); ?>" type="hidden" value="<?php echo $row_dl["ex_s_cheap"]; ?>">
            
            <hr>

          </div>
          <div class="col-xs-12 col-md-2"></div>
        </div>

        <?php 
      }
    }

    ?>
    <input name="<?php echo "ex_num"; ?>" type="hidden" value=" <?php echo $l-1; ?>">
    <?php
    if(($l-1) < $ex_numberExams ){
      ?>
      <h5 style="text-align: center; color: #FF3333;">ชุดข้อสอบไม่พร้อมใช้งาน เนื่องจากจำนวนข้อสอบไม่ครบตามจำนวน</h5>
      <div class="modal-footer " style="text-align: center;" >
        <a href="listExamination.php" type="button"  class="btn btn-default" data-dismiss="modal" >ยกเลิก</a>
        <button type="submit" class="btn btn-primary" name="subInserExams" disabled="disabled">ส่งข้อมูล</button>
      </div>
      <?php
    }else{
      ?>
      <div class="modal-footer " style="text-align: center;" >
        <a href="listExamination.php" type="button"  class="btn btn-default" data-dismiss="modal">ยกเลิก</a>
        <button type="submit" class="btn btn-primary" name="subInserExams">ส่งข้อมูล</button>
      </div>

      <?php
    }
    ?>

  </form>
</div>
</div>

<?php
if(isset($_POST['subInserExams'])){
 $ex_num=$_POST["ex_num"];
 $score=0;
 $IDUsers =$_SESSION['u_id'];
 $ExamDate=date("Y-m-d H:i:s");
 for ($i=1; $i < $ex_num+1 ; $i++) { 
   if(trim($_POST["ro$i"]) == trim($_POST["ex_s_cheap$i"]))
   {
    (int)$score=(int)$score+1;
    
  }
}
$stmt = $dbc->prepare("INSERT INTO examscore (ExamScore,IDExamination,IDUsers,ExamDate) VALUES(?,?,?,?)");
$stmt->bind_param("ssss",$score,$ex_id,$IDUsers,$ExamDate);
$stmt->execute();
//echo $score;
?>
<div class="container">
  <div class="modal show" id="myModal" role="dialog">
    <div class="modal-dialog">

      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <a href="userScore.php" type="button" class="close"  onclick = "$('.modal').removeClass('show').addClass('fade');" data-dismiss="modal">&times;</a>
          <h4 class="modal-title">สำเร็จ</h4>
        </div>
        <div class="modal-body">
          <p>ผลการสอบ คุณได้คะแนน <?php echo($score." คะแนน คะแนนเต็ม". $ex_num ) ?>  สำเร็จ.</p>
        </div>
        <div class="modal-footer">
          <a type="button" href="userScore.php"  class="btn btn-default" onclick = "$('.modal').removeClass('show').addClass('fade');" data-dismiss="modal">Close</a>
        </div>
      </div>

    </div>
  </div>
</div>
<?php


}
?>

<script src="js/jquery.js"></script>
<script src="js/checkforms.js"></script>
<script src="js/inputdate.js"></script>
<script src="js/jquery.datetimepicker.js"></script>
<script src="build/jquery.datetimepicker.full.js"></script>
<script language="JavaScript">
  window.history.forward(1);
  document.attachEvent("onkeydown", my_onkeydown_handler);
  function my_onkeydown_handler()
  {
    switch (event.keyCode)
{ case 116 : // 'F5'
event.returnValue = false;
event.keyCode = 0;
window.status = "ไม่สามารถทำการ Refresh หรือ กด F5 ได้ ค่ะ";
break; 
}
}
</script>
</body>
</html>

