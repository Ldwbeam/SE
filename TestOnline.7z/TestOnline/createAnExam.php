
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>เพิ่มลบแก้ไขข้อสอบ</title>
  <link rel="stylesheet" href="css/jquery.datetimepicker.css">
</head>
<body>

  <?php
  $date = date("Y-m-d");
  function getNumDay($d1,$d2){
    $dArr1    = preg_split("/-/", $d1);
    list($year1, $month1, $day1) = $dArr1;
    $Day1 =  mktime(0,0,0,$month1,$day1,$year1);

    $dArr2    = preg_split("/-/", $d2);
    list($year2, $month2, $day2) = $dArr2;
    $Day2 =  mktime(0,0,0,$month2,$day2,$year2);

    return round(abs( $Day2 - $Day1 ) / 86400 )+1;
  }
  function DateThai1($strDate)
  {
    $strYear = date("Y",strtotime($strDate));
    $strMonth= date("m",strtotime($strDate));
    $strDay= date("d",strtotime($strDate));
    $strHour= date("H",strtotime($strDate));
    $strMinute= date("i",strtotime($strDate));
    $strSeconds= date("s",strtotime($strDate));
    $tt ="T".$strHour;
    return "$strYear-$strMonth-$strDay$tt:$strMinute:00";
  }
  ?>
  <div id="wrapper">
    <?php
    require_once("mysqlconnect.php");
    include('manu.php');

    if(isset($_GET["DeletEx_id"])){
      $ex_id = $_REQUEST["DeletEx_id"];
      $ex_d_id = "";
      $sql=" SELECT ex_d_header_id,ex_d_id FROM examination_detail WHERE ex_d_header_id ='$ex_id'";
      $result = $dbc->query($sql);
      if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()){
         $ex_d_id =  $row["ex_d_id"];

         $delete0 = $dbc->prepare("DELETE FROM examination_subitem WHERE ex_s_d_id = ?");
         $delete0->bind_param("s",$row["ex_d_id"]);
         $delete0->execute();
       }
     }
     $delete1 = $dbc->prepare("DELETE FROM examination_detail WHERE ex_d_header_id = ?");
     $delete1->bind_param("s",$ex_id);
     $delete1->execute();

     $delete2 = $dbc->prepare("DELETE FROM examination_header WHERE  ex_id = ?");
     $delete2->bind_param("s",$ex_id);
     $delete2->execute();

     ?>
     <div class="container">
      <div class="modal show" id="myModal" role="dialog">
        <div class="modal-dialog">

          <!-- Modal content-->
          <div class="modal-content">
            <div class="modal-header">
              <a href="index.php" type="button" class="close"   data-dismiss="modal">&times;</a>
              <h4 class="modal-title">สำเร็จ</h4>
            </div>
            <div class="modal-body">
              <p>ลบข้อมูลของสำเร็จ </p>
            </div>
            <div class="modal-footer">
              <a type="button" href="index.php"  class="btn btn-default"  data-dismiss="modal">Close</a>
            </div>
          </div>

        </div>
      </div>
    </div>
    <?php

  }
  if(isset($_GET["editEx_id"])){

    $ex_id = $_REQUEST["editEx_id"];
    $ex_d_header_id ="";
    $ex_detail ="";
    $ex_name ="";
    $ex_course ="";
    $ex_numberExams ="";
    $ex_class ="";
    $ex_OpenExam ="";
    $ex_CloseExam ="";
    require_once("mysqlconnect.php");
    include('manu.php');
    $sql=" SELECT EH.ex_id,EH.ex_id,EH.ex_name,EH.ex_detail,EH.ex_course,EH.ex_numberExams,EH.ex_idProfessor,EH.ex_date,EH.ex_class,EH.ex_OpenExam,EH.ex_CloseExam,U.u_firstName,U.u_lastName ,S.NameSchool FROM examination_header EH, users U,school S WHERE EH.ex_idProfessor =U.u_id AND U.u_schoolID=s.IDSchool AND ex_id = '$ex_id'";
    $result = $dbc->query($sql);
    if ($result->num_rows > 0) {
      while($row = $result->fetch_assoc()){
        $ex_d_header_id = $row["ex_id"];
        $ex_name = $row["ex_name"];
        $ex_detail =$row["ex_detail"];
        $ex_course= $row["ex_course"];
        $ex_numberExams =$row["ex_numberExams"];
        $ex_class =$row["ex_class"];
        $ex_OpenExam =$row["ex_OpenExam"];
        $ex_CloseExam =$row["ex_CloseExam"];
      }
    }

    ?>
    <div id="page-wrapper">
     <div class="container-fluid">
      <div class="row">
        <div class="col-lg-12">
          <h1 class="page-header">
            แก้ไขชุดข้อสอบ
          </h1>
          <ol class="breadcrumb">
            <li class="active">
              <i class="glyphicon glyphicon-th"></i> แก้ไขชุดข้อสอบ
            </li>
          </ol>
        </div>
      </div>

      <div class="row">
        <div class="col-lg-12">
          <form class="form-horizontal" action="" id="myform1" name="frmMain" method="post" onkeypress="return event.keyCode != 13;" >

           <div class="row">
            <div class="col-sm-12 ">
              <label for="inputEmail3" class="col-sm-2 control-label">หัวข้อชุดข้อสอบ<t style="color: #ff0000;">*</t></label>
              <div class="col-sm-8 form-group ">
                <input type="text" class="form-control css-require" id="exampleInputEmail2" placeholder="เรื่อง" name="txtex_name" value="<?php echo($ex_name);?>">
                <input type="text" hidden name="txtex_id" value="<?php echo($ex_d_header_id);?>">
              </div>
            </div>
          </div>

          <div class="row">
            <div class="col-sm-12 ">
              <label for="inputEmail3" class="col-sm-2 control-label">รายละเอียดชุดข้อสอบ<t style="color: #ff0000;">*</t></label>
              <div class="col-sm-8 form-group ">
                <textarea row="5" class="form-control css-require" id="exampleInputEmail2" placeholder="รายละเอียด" name="txtex_detail" ><?php echo($ex_detail);?></textarea>
              </div>
            </div>
          </div>

          <div class="row">
            <div class="col-sm-12 ">
              <label for="inputEmail3" class="col-sm-2 control-label">รายวิชา<t style="color: #ff0000;">*</t></label>
              <div class="col-sm-8 form-group ">
                <input type="text" class="form-control css-require" id="exampleInputEmail2" placeholder="รายวิชา" name="txtex_course" value="<?php echo($ex_course);?>">
              </div>
            </div>
          </div>

          <div class="row">
            <div class="col-sm-12 ">
              <label for="inputEmail3" class="col-sm-2 control-label">จำนวนหัวข้อ<t style="color: #ff0000;">*</t></label>
              <div class="col-sm-2 form-group ">
                <input type="number" class="form-control css-require" id="exampleInputEmail2" placeholder="##" name="txtex_numberExams" value="<?php echo($ex_numberExams);?>">
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-sm-12 ">
              <label for="inputEmail3" class="col-sm-2 control-label">ชั้นเรียน<t style="color: #ff0000;">*</t></label>
              <div class="col-sm-2 form-group ">
                <select class="form-control css-require" name="opClass" id="opClass">
                  <option value="">เลือกรายการ </option>
                  <option value="<?php echo($ex_class); ?>" selected ><?php echo($ex_class); ?> </option>
                  <option value="ม.1" >ม.1 </option>
                  <option value="ม.2" >ม.2 </option>
                  <option value="ม.3" >ม.3 </option>
                  <option value="ม.4" >ม.4 </option>
                  <option value="ม.5" >ม.5 </option>
                  <option value="ม.6" >ม.6 </option>
                </select> 
              </div>
            </div>
          </div>

          <div class="row">
            <div class="col-sm-12 ">
              <label for="inputEmail3" class="col-sm-2 control-label">วันที่เปิดสอบ<t style="color: #ff0000;">*</t></label>
              <div class="col-sm-4 form-group ">
               <input id="datetimepicker"  class="form-control css-require" name="detOpentExa" type="text" value="<?php echo $ex_OpenExam; ?>">
             </div>
           </div>
         </div>
         <div class="row">
          <div class="col-sm-12 ">
            <label for="inputEmail3" class="col-sm-2 control-label">วันที่ปิดสอบ<t style="color: #ff0000;">*</t></label>
            <div class="col-sm-4 form-group ">
              <input id="datetimepicker1"  class="form-control css-require" name="detoffExa" type="text" value="<?php echo $ex_CloseExam; ?>">
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" onclick="window.location.reload()" class="btn btn-default" data-dismiss="modal">ยกเลิก</button>
          <button type="submit" class="btn btn-primary" name="subEditUser">บันทึก</button>
        </div>

      </form>
    </div>
  </div>
</div>
<?php
}else{
  ?>
  <div id="page-wrapper">
   <div class="container-fluid">
    <div class="row">
      <div class="col-lg-12">
        <h1 class="page-header">
          สร้างข้อสอบ
        </h1>
        <ol class="breadcrumb">
          <li class="active">
            <i class="glyphicon glyphicon-th"></i> สร้างข้อสอบ
          </li>
        </ol>
      </div>
    </div>

    <div class="row">
      <div class="col-lg-12">
        <form class="form-horizontal" action="" id="myform1" name="frmMain" method="post" onkeypress="return event.keyCode != 13;" >

         <div class="row">
          <div class="col-sm-12 ">
            <label for="inputEmail3" class="col-sm-2 control-label">หัวข้อชุดข้อสอบ<t style="color: #ff0000;">*</t></label>
            <div class="col-sm-8 form-group ">
              <input type="text" class="form-control css-require" id="exampleInputEmail2" placeholder="เรื่อง" name="txtex_name">
            </div>
          </div>
        </div>

        <div class="row">
          <div class="col-sm-12 ">
            <label for="inputEmail3" class="col-sm-2 control-label">รายละเอียดชุดข้อสอบ<t style="color: #ff0000;">*</t></label>
            <div class="col-sm-8 form-group ">
              <textarea row="5" class="form-control css-require" id="exampleInputEmail2" placeholder="รายละเอียด" name="txtex_detail"></textarea>
            </div>
          </div>
        </div>

        <div class="row">
          <div class="col-sm-12 ">
            <label for="inputEmail3" class="col-sm-2 control-label">รายวิชา<t style="color: #ff0000;">*</t></label>
            <div class="col-sm-8 form-group ">
              <input type="text" class="form-control css-require" id="exampleInputEmail2" placeholder="รายวิชา" name="txtex_course">
            </div>
          </div>
        </div>

        <div class="row">
          <div class="col-sm-12 ">
            <label for="inputEmail3" class="col-sm-2 control-label">จำนวนหัวข้อ<t style="color: #ff0000;">*</t></label>
            <div class="col-sm-2 form-group ">
              <input type="number" class="form-control css-require" id="exampleInputEmail2" placeholder="##" name="txtex_numberExams">
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-sm-12 ">
            <label for="inputEmail3" class="col-sm-2 control-label">ชั้นเรียน<t style="color: #ff0000;">*</t></label>
            <div class="col-sm-2 form-group ">
              <select class="form-control css-require" name="opClass" id="opClass">
                <option value="">เลือกรายการ </option>
                <option value="ม.1" >ม.1 </option>
                <option value="ม.2" >ม.2 </option>
                <option value="ม.3" >ม.3 </option>
                <option value="ม.4" >ม.4 </option>
                <option value="ม.5" >ม.5 </option>
                <option value="ม.6" >ม.6 </option>
              </select> 
            </div>
          </div>
        </div>

        <div class="row">
          <div class="col-sm-12 ">
            <label for="inputEmail3" class="col-sm-2 control-label">วันที่เปิดสอบ<t style="color: #ff0000;">*</t></label>
            <div class="col-sm-4 form-group ">
              <input id="datetimepicker"  class="form-control css-require" name="detOpentExa" type="text" >
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-sm-12 ">
            <label for="inputEmail3" class="col-sm-2 control-label">วันที่ปิดสอบ<t style="color: #ff0000;">*</t></label>
            <div class="col-sm-4 form-group ">
             <input id="datetimepicker1"  class="form-control css-require" name="detoffExa" type="text" >

           </div>
         </div>
       </div>
       <div class="modal-footer">
        <button type="button" onclick="window.location.reload()" class="btn btn-default" data-dismiss="modal">ยกเลิก</button>
        <button type="submit" class="btn btn-primary" name="subInserUser">บันทึก</button>
      </div>

    </form>
  </div>
</div>
</div>
<?php
}
?>
</div>
<?php
if(isset($_POST['subInserUser'])){
  $ex_name=$_POST['txtex_name'];
  $ex_detail=$_POST['txtex_detail'];
  $ex_course=$_POST['txtex_course'];
  $ex_numberExams=$_POST['txtex_numberExams'];
  $ex_idProfessor = $_SESSION['u_id'];
  $ex_class = $_POST['opClass'];
  $ex_OpenExam = $_POST['detOpentExa'];
  $ex_CloseExam = $_POST['detoffExa'];
  $ex_date = date("Y-m-d H:i:s");
  $ex_id = substr(date("d"),-2).time();
  $stmt = $dbc->prepare("INSERT INTO examination_header(  ex_id,ex_name,ex_detail,ex_course,ex_numberExams,ex_idProfessor,ex_date,ex_class,ex_OpenExam,ex_CloseExam) VALUES(?,?,?,?,?,?,?,?,?,?)");
  $stmt->bind_param("ssssssssss",$ex_id,$ex_name,$ex_detail,$ex_course,$ex_numberExams,$ex_idProfessor,$ex_date,$ex_class,$ex_OpenExam,$ex_CloseExam);
  $stmt->execute();

  $sql=" SELECT ex_id,ex_id,ex_name,ex_detail,ex_course,ex_numberExams,ex_idProfessor,ex_date FROM examination_header WHERE ex_id = '$ex_id'";
  $result = $dbc->query($sql);
  $exId ="";
  $exName = "";
  if ($result->num_rows > 0) {


    while($row = $result->fetch_assoc()){
      $exId = $row["ex_id"];
      $exName = $row["ex_name"];
    }
    ?>
    <div class="container">
      <div class="modal show" id="myModal" role="dialog">
        <div class="modal-dialog">

          <!-- Modal content-->
          <div class="modal-content">
            <div class="modal-header">
              <a href="examinationDetail.php?exId=<?=$exId;?>" type="button" class="close"   data-dismiss="modal">&times;</a>
              <h4 class="modal-title">สำเร็จ</h4>
            </div>
            <div class="modal-body">
              <p>บันทึกข้อมูลของสำเร็จ รหัสชุดข้อสอบคือ <?php echo("<b>".$exId."</b> ชุดข้อสอบชื่อ <b>". $exName."</b>") ?>  คุณต้องทำการบันทึกรายละเอียดข้อสอบต่อไป.</p>
            </div>
            <div class="modal-footer">
              <a type="button" href="examinationDetail.php?exId=<?=$exId;?>" class="btn btn-default"  data-dismiss="modal">Close</a>
            </div>
          </div>

        </div>
      </div>
    </div>
    <?php
  }
}
?>

<?php
if(isset($_POST['subEditUser'])){
 $ex_id=$_POST['txtex_id'];
 $ex_name=$_POST['txtex_name'];
 $ex_detail=$_POST['txtex_detail'];
 $ex_course=$_POST['txtex_course'];
 $ex_numberExams=$_POST['txtex_numberExams'];
 $ex_idProfessor = $_SESSION['u_id'];
 $ex_class = $_POST['opClass'];
 $ex_OpenExam = $_POST['detOpentExa'];
 $ex_CloseExam = $_POST['detoffExa'];
 $stmt = $dbc->prepare("UPDATE examination_header SET ex_name=?,ex_detail=?,ex_course=?,ex_numberExams=?,ex_idProfessor=?,ex_date=?,ex_class=?,ex_OpenExam=?,ex_CloseExam=? WHERE ex_id='$ex_id' ");
 $stmt->bind_param("sssssssss",$ex_name,$ex_detail,$ex_course,$ex_numberExams,$ex_idProfessor,$ex_date,$ex_class,$ex_OpenExam,$ex_CloseExam);
 $stmt->execute();

 $sql=" SELECT ex_id,ex_id,ex_name,ex_detail,ex_course,ex_numberExams,ex_idProfessor,ex_date FROM examination_header WHERE ex_id = '$ex_id'";
 $result = $dbc->query($sql);
 $exId ="";
 $exName = "";
 if ($result->num_rows > 0) {


  while($row = $result->fetch_assoc()){
    $exId = $row["ex_id"];
    $exName = $row["ex_name"];
  }
  ?>
  <div class="container">
    <div class="modal show" id="myModal" role="dialog">
      <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
          <div class="modal-header">
            <a href="examinationDetail.php?exId=<?=$exId;?>" type="button" class="close"   data-dismiss="modal">&times;</a>
            <h4 class="modal-title">สำเร็จ</h4>
          </div>
          <div class="modal-body">
            <p>แก้ไขข้อมูลสำเร็จ รหัสชุดข้อสอบคือ <?php echo("<b>".$exId."</b> ชุดข้อสอบชื่อ <b>". $exName."</b>") ?>  คุณต้องทำการบันทึกรายละเอียดข้อสอบต่อไป.</p>
          </div>
          <div class="modal-footer">
            <a type="button" href="examinationDetail.php?exId=<?=$exId;?>"   class="btn btn-default"  data-dismiss="modal">Close</a>
          </div>
        </div>

      </div>
    </div>
  </div>
  <?php
}
}
?>

<script src="js/jquery.js"></script>
<script src="js/checkforms.js"></script>
<script src="js/inputdate.js"></script>
<script src="js/jquery.datetimepicker.js"></script>
<script src="build/jquery.datetimepicker.full.js"></script>
<script >
  jQuery('#datetimepicker').datetimepicker();
  jQuery('#datetimepicker1').datetimepicker();
  var $datepicker = $('#datetimepicker');
</script>
</body>
</html>