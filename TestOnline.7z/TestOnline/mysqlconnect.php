<?php
$dbc = mysqli_connect("localhost","root","","test_online");
$dbc->set_charset("utf8");
?>