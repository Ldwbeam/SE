
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>ค้นหาชุดข้อสอบ</title>
</head>
<body>

  <?php
  $datenow = date("Y-m-d H:i:s");
  $date = date("Y-m-d");
  function DateThai($strDate)
  {
    $strYear = date("Y",strtotime($strDate))+543;
    $strMonth= date("n",strtotime($strDate));
    $strDay= date("j",strtotime($strDate));
    $strHour= date("H",strtotime($strDate));
    $strMinute= date("i",strtotime($strDate));
    $strSeconds= date("s",strtotime($strDate));
    $strMonthCut = Array("","ม.ค.","ก.พ.","มี.ค.","เม.ย.","พ.ค.","มิ.ย.","ก.ค.","ส.ค.","ก.ย.","ต.ค.","พ.ย.","ธ.ค.");
    $strMonthThai=$strMonthCut[$strMonth];
    return "$strDay $strMonthThai $strYear เวลา $strHour:$strSeconds น.";
  }

  ?>
  <div id="wrapper">
    <?php
    require_once("mysqlconnect.php");
    include('manu.php');
    ?>
    <div id="page-wrapper">
     <div class="container-fluid">
      <div class="row">
        <div class="col-lg-12">
          <h1 class="page-header">
            ค้นหาชุดข้อสอบ
          </h1>
        </div>
      </div>

      <div class="row">
        <div class="col-lg-12">
          <form class="form-horizontal" action="" id="myform1" name="frmMain" method="post" onkeypress="return event.keyCode != 13;" >
            <div class="input-group">
              <input type="text" name="txtex_id" class="form-control" placeholder="ระบุรหัสชุดข้อสอบ...">
              <span class="input-group-btn">
                <button type="submis" class="btn btn-default" name="sechiud" type="button">ค้นหา!</button>
              </span>
            </div>
          </form>
        </div>
      </div>

      <?php
      $IDUsers =$_SESSION['u_id'];
      $UClass = $_SESSION['u_class'];
      $u_schoolID = $_SESSION['u_schoolID'];
      ?>
      <div class="row">
       <div class="list-group">
        <?php 
        if(isset($_POST['sechiud'])){
          $ex_id = $_POST['txtex_id'];
          $sql_dl=" SELECT eh.ex_id,eh.ex_name,eh.ex_detail,eh.ex_course,eh.ex_date,eh.ex_numberExams,eh.ex_idProfessor,eh.ex_class,eh.ex_OpenExam,eh.ex_CloseExam,u.u_firstName,u.u_lastName,u.u_schoolID FROM examination_header eh ,users u WHERE eh.ex_idProfessor = u.u_id AND eh.ex_id = '$ex_id' AND eh.ex_class ='$UClass' AND u.u_schoolID ='$u_schoolID' ";
        }else{
          $sql_dl=" SELECT eh.ex_id,eh.ex_name,eh.ex_detail,eh.ex_course,eh.ex_date,eh.ex_numberExams,eh.ex_idProfessor,eh.ex_class,eh.ex_OpenExam,eh.ex_CloseExam,u.u_firstName,u.u_lastName,u.u_schoolID FROM examination_header eh ,users u WHERE eh.ex_idProfessor = u.u_id  AND eh.ex_class ='$UClass' AND u.u_schoolID ='$u_schoolID' ";
        }
        $result_dl = $dbc->query($sql_dl);
        $l=1;
        if ($result_dl->num_rows > 0) {
          while($row_dl = $result_dl->fetch_assoc()){
            ?>
            <br>
            <div  class="list-group-item">

              <h4 class="list-group-item-heading"><?php echo $l++ .". ".$row_dl["ex_name"]; ?></h4>
              <p  class="list-group-item-text"><?php echo "<b>รายละเอียด</b> ".$row_dl["ex_detail"]; ?></p>
              <p  class="list-group-item-text"><?php echo "<b>รายวิชา </b> ".$row_dl["ex_course"]; ?></p>
              <p  class="list-group-item-text"><?php echo "<b>ผู้สอน </b> ".$row_dl["u_firstName"]." ".$row_dl["u_lastName"]; ?></p>
              <p  class="list-group-item-text"><?php echo "<b>รหัสชุดข้อสอบ </b> ".$row_dl["ex_id"]; ?></p>
              <p  class="list-group-item-text"><?php echo "<b>จำนวนข้อสอบ </b> ".$row_dl["ex_numberExams"] ." ข้อ"; ?></p>
              <p  class="list-group-item-text"><?php echo "<b>วันที่เปิดสอบ </b> ".DateThai($row_dl["ex_OpenExam"]) ."  <b>วันที่ปิดสอบ </b> ".DateThai($row_dl["ex_CloseExam"]); ?></p>
              <br>
              <?php

              $idex = $row_dl["ex_id"];
              //echo $datenow ."=".$row_dl["ex_OpenExam"];
              if($row_dl["ex_OpenExam"] > $datenow ){
               ?>
                <button  class="btn " disabled="disabled"> ยังไม่เปิดให้สอบ</button>
               <?php
              }else{
                $sql_ds=" SELECT COUNT(IDUsers) AS countIDuser FROM examscore WHERE  IDUsers ='$IDUsers' AND IDExamination = '$idex' ";
                $result_ds = $dbc->query($sql_ds);
                if ($result_ds->num_rows > 0) {
                  while($row_ds = $result_ds->fetch_assoc()){
                    if($row_ds["countIDuser"] == 0){

                      if($row_dl["ex_CloseExam"] >= $datenow){
                        ?>
                        
                        <a href="Exams.php?exId=<?=$row_dl["ex_id"];?>" class="btn btn-primary" > เริ่มทำข้อสอบ</a>
                        <?php
                      }else{
                        ?>
                        <a  class="btn btn-warning" disabled="disabled"> ปิดการสอบไปแล้ว</a>
                        <?php
                      }
                    }else{?>
                      <a  class="btn btn-success" disabled="disabled"> คุณได้ทำชุดข้อสอบนี้แล้ว</a>
                      <?php
                    }//if($row_ds["countIDuser"] == 0){
                  }//while
                }//if ($result_ds->num_rows > 0) {
              }//if($row_dl["ex_OpenExam"] >= $datenow ){
          ?>
        </div>
        <?php
      }
    }else{
      echo("<h3 class='page-header'> ไม่พบชุดข้อสอบ </h3>");
    }
    ?>
  </div>
</div>
</div>
</div>
</div>
</div>
<script src="js/jquery.js"></script>
<script src="js/checkforms.js"></script>
<script src="js/inputdate.js"></script>
<script src="js/jquery.datetimepicker.js"></script>
<script src="build/jquery.datetimepicker.full.js"></script>
</body>
</html>